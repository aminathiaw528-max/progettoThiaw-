# ⚔️ AMINUP — Avvio rapido

E-commerce a tema *Baki Hanma*: schede di allenamento, proteine, integratori e attrezzatura.

> Guida completa con risoluzione problemi: **[docs/00-guida-avvio.md](docs/00-guida-avvio.md)**

---

## 1. Prerequisito: Node.js

Serve **Node.js 22.5 o superiore** (consigliata la **24 LTS**).
Controlla se ce l'hai già aprendo PowerShell:

```powershell
node --version
```

Se il comando non viene riconosciuto, installalo e **riapri il terminale**:

```powershell
winget install OpenJS.NodeJS.LTS
```

---

## 2. Avvia il BACKEND — primo terminale

Apri PowerShell **nella cartella del progetto** (quella che contiene `server/` e `client/`):

```powershell
cd server
npm install
npm run seed
npm run dev
```

Quando vedi `AMINUP server in ascolto su http://localhost:4000` è pronto.
**Lascia questo terminale aperto.**

---

## 3. Avvia il FRONTEND — secondo terminale

Apri un **secondo** PowerShell nella cartella del progetto:

```powershell
cd client
npm install
npm run dev
```

---

## 4. Apri il sito

👉 **http://localhost:5173**

---

## Per provarlo subito

| Cosa | Valore |
|------|--------|
| Carta di test | `4242 4242 4242 4242` — scad. `12/30` — CVC `123` |
| Coupon | `BAKI20` (−20%), `AMINUP15` (−15%), `ARENA5` (−5 €) |
| Coupon scaduto (per vedere l'errore) | `SCADUTO` |

**Registrati con una email vera**: il dominio viene verificato tramite record MX DNS,
quindi indirizzi inventati vengono rifiutati (è un requisito del progetto).

Le email non arrivano in una casella reale: il sistema è in modalità test e mostra
un **link di anteprima** a schermo e nella console del backend.

**Area venditore** (`/seller`): l'account venditore è indicato in
[docs/06-credenziali.md](docs/06-credenziali.md). Se avvii con un database vuoto, il primo
utente che apre `/seller` può rivendicare il ruolo con un click.

---

## Note

- `npm install` serve **solo al primo avvio**.
- Per spegnere tutto: **Ctrl+C** in entrambi i terminali.
- Se rilanci `npm run seed`, **riavvia il backend** (il catalogo è caricato in memoria).
- Non serve installare né configurare alcun database: SQLite è integrato in Node.
