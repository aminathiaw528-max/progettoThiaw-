import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';

process.env.NODE_ENV = 'test';
process.env.VERIFY_EMAIL_MX = 'false'; // niente rete nei test
process.env.EMAIL_MODE = 'ethereal';

// Import dopo aver settato le env
const { default: app } = await import('../src/index.js');
const { seed } = await import('../src/db/seed.js');

before(async () => {
  await seed(); // assicura catalogo + coupon di test
});

let token;
const uniqueEmail = `guerriero_${Date.now()}@example.com`;

test('health check', async () => {
  const res = await request(app).get('/api/health');
  assert.equal(res.status, 200);
  assert.equal(res.body.status, 'ok');
});

test('registrazione crea utente e ritorna token', async () => {
  const res = await request(app)
    .post('/api/auth/register')
    .send({ name: 'Baki', email: uniqueEmail, password: 'segreta123' });
  assert.equal(res.status, 201);
  assert.ok(res.body.token);
  token = res.body.token;
});

test('registrazione con email già usata → 409', async () => {
  const res = await request(app)
    .post('/api/auth/register')
    .send({ name: 'Baki', email: uniqueEmail, password: 'segreta123' });
  assert.equal(res.status, 409);
});

test('login con password errata → 401', async () => {
  const res = await request(app)
    .post('/api/auth/login')
    .send({ email: uniqueEmail, password: 'sbagliata' });
  assert.equal(res.status, 401);
});

test('catalogo prodotti non vuoto', async () => {
  const res = await request(app).get('/api/products');
  assert.equal(res.status, 200);
  assert.ok(res.body.products.length > 0);
});

test('carrello richiede autenticazione → 401', async () => {
  const res = await request(app).get('/api/cart');
  assert.equal(res.status, 401);
});

test('flusso completo: aggiungi al carrello, coupon, checkout, ordine', async () => {
  // aggiungi prodotto
  let res = await request(app)
    .post('/api/cart/items')
    .set('Authorization', `Bearer ${token}`)
    .send({ productId: 'sch-001', qty: 2 });
  assert.equal(res.status, 201);

  // valida coupon BAKI20 (20%)
  res = await request(app)
    .post('/api/coupons/validate')
    .set('Authorization', `Bearer ${token}`)
    .send({ code: 'BAKI20', subtotal: 59.8 });
  assert.equal(res.status, 200);
  assert.ok(Math.abs(res.body.discount - 11.96) < 0.01);

  // checkout con carta valida (numero test Luhn-valido)
  res = await request(app)
    .post('/api/payment/checkout')
    .set('Authorization', `Bearer ${token}`)
    .send({ method: 'card', couponCode: 'BAKI20', card: { number: '4242424242424242', exp: '12/30', cvc: '123' } });
  assert.equal(res.status, 201);
  assert.equal(res.body.order.status, 'paid');

  // lo storico contiene l'ordine
  res = await request(app).get('/api/orders').set('Authorization', `Bearer ${token}`);
  assert.equal(res.status, 200);
  assert.ok(res.body.orders.length >= 1);
  // il PAN non deve MAI comparire nella risposta
  assert.ok(!JSON.stringify(res.body).includes('4242424242424242'));
});

test('checkout con carta non valida (Luhn) → 402', async () => {
  await request(app).post('/api/cart/items').set('Authorization', `Bearer ${token}`)
    .send({ productId: 'int-001', qty: 1 });
  const res = await request(app)
    .post('/api/payment/checkout')
    .set('Authorization', `Bearer ${token}`)
    .send({ method: 'card', card: { number: '1234567890123456', exp: '12/30', cvc: '123' } });
  assert.equal(res.status, 402);
});
