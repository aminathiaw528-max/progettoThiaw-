import { pathToFileURL } from 'node:url';
import { products } from './nedb.js';
import db, { transaction } from './sqlite.js';

// Link "come si esegue": ricerca video dell'esercizio
const yt = (q) => `https://www.youtube.com/results?search_query=${encodeURIComponent(q + ' come si esegue tecnica')}`;

// Catalogo a tema Baki Hanma / sport (NoSQL).
// `art` seleziona l'illustrazione SVG generata dal client (components/ProductArt.jsx).
const CATALOG = [
  // ---------------- SCHEDE DI ALLENAMENTO (prodotti digitali) ----------------
  {
    _id: 'sch-001', category: 'schede', name: 'Piano FORZA — Yujiro', price: 29.9,
    art: 'barbell', tags: ['forza', 'avanzato'], stock: 999, level: 'Avanzato', duration: '12 settimane',
    description: 'Programma di forza pura 12 settimane ispirato all\'Ogre. Squat, panca, stacco: diventa il più forte.',
    exercises: [
      { name: 'Squat con bilanciere', sets: '5×5', how: 'Bilanciere sui trapezi, piedi larghezza spalle e punte leggermente aperte. Scendi spingendo i fianchi indietro mantenendo la schiena neutra, fino a coscia parallela al pavimento. Risali spingendo con i talloni.', video: yt('squat con bilanciere') },
      { name: 'Panca piana', sets: '5×5', how: 'Sdraiato, scapole retratte e piedi a terra. Impugna poco più largo delle spalle, scendi controllando fino a sfiorare il petto, poi spingi in alto senza staccare la schiena dalla panca.', video: yt('panca piana bilanciere') },
      { name: 'Stacco da terra', sets: '3×5', how: 'Piedi sotto il bilanciere, presa poco fuori dalle gambe. Petto alto e schiena neutra: spingi il pavimento con le gambe mantenendo il bilanciere aderente alle tibie fino a estensione completa dell\'anca.', video: yt('stacco da terra deadlift') },
      { name: 'Military press', sets: '4×6', how: 'In piedi, bilanciere all\'altezza delle clavicole. Spingi sopra la testa contraendo glutei e addome per non inarcare la schiena, fino a braccia distese.', video: yt('military press') },
    ],
  },
  {
    _id: 'sch-002', category: 'schede', name: 'Piano IPERTROFIA — Baki', price: 24.9,
    art: 'dumbbell', tags: ['massa', 'intermedio'], stock: 999, level: 'Intermedio', duration: '8 settimane',
    description: 'Costruzione muscolare 8 settimane. Volume alto, cedimento controllato. Cresci come un mostro.',
    exercises: [
      { name: 'Panca inclinata manubri', sets: '4×10', how: 'Panca a 30-45°. Manubri all\'altezza del petto, gomiti a circa 45° dal busto. Spingi verso l\'alto avvicinando i manubri senza farli scontrare.', video: yt('panca inclinata manubri') },
      { name: 'Rematore con bilanciere', sets: '4×10', how: 'Busto inclinato a ~45°, schiena neutra. Tira il bilanciere verso l\'ombelico portando i gomiti indietro e stringendo le scapole, poi scendi controllato.', video: yt('rematore bilanciere') },
      { name: 'Affondi con manubri', sets: '3×12', how: 'Passo avanti ampio, scendi finché il ginocchio posteriore sfiora il pavimento mantenendo il busto eretto. Spingi con il tallone anteriore per tornare su.', video: yt('affondi con manubri') },
      { name: 'Curl bicipiti', sets: '3×12', how: 'Gomiti fermi vicino ai fianchi, solleva i manubri ruotando i polsi verso l\'esterno. Scendi lentamente in 2-3 secondi senza dondolare il busto.', video: yt('curl bicipiti manubri') },
    ],
  },
  {
    _id: 'sch-003', category: 'schede', name: 'Piano STREET FIGHTER — Doppo', price: 19.9,
    art: 'calisthenics', tags: ['calisthenics', 'principiante'], stock: 999, level: 'Principiante', duration: '6 settimane',
    description: 'Calisthenics e condizionamento a corpo libero. Nessuna scusa, solo il tuo corpo e la volontà.',
    exercises: [
      { name: 'Trazioni alla sbarra', sets: '5×max', how: 'Presa prona poco più larga delle spalle. Parti da braccia distese, tira portando il petto verso la sbarra e le scapole in basso. Scendi in controllo fino a distensione completa.', video: yt('trazioni alla sbarra pull up') },
      { name: 'Piegamenti sulle braccia', sets: '4×15', how: 'Corpo in linea da testa a talloni, mani sotto le spalle. Scendi finché il petto sfiora terra tenendo i gomiti a ~45°, poi spingi mantenendo addome e glutei contratti.', video: yt('piegamenti sulle braccia push up') },
      { name: 'Dip alle parallele', sets: '4×10', how: 'Braccia distese sulle parallele, busto leggermente inclinato in avanti. Scendi fino a gomiti a 90°, poi spingi in alto senza bloccare violentemente i gomiti.', video: yt('dip parallele') },
      { name: 'Plank', sets: '3×60"', how: 'Appoggio su avambracci e punte dei piedi, corpo perfettamente in linea. Contrai addome e glutei, non far cedere i lombari né alzare il bacino.', video: yt('plank esecuzione corretta') },
    ],
  },
  {
    _id: 'sch-004', category: 'schede', name: 'Piano UNDERGROUND — Full Body', price: 34.9,
    art: 'kettlebell', tags: ['full-body', 'avanzato'], stock: 999, level: 'Avanzato', duration: '10 settimane',
    description: 'Il programma dell\'arena: full body 4× settimana, forza + condizionamento. Solo per chi non molla.',
    exercises: [
      { name: 'Kettlebell swing', sets: '5×20', how: 'Piedi larghi, anche indietro e schiena neutra. Il movimento nasce dall\'anca: proietta il kettlebell in avanti con una spinta esplosiva di glutei, non con le braccia.', video: yt('kettlebell swing') },
      { name: 'Front squat', sets: '4×8', how: 'Bilanciere sui deltoidi anteriori, gomiti alti. Scendi mantenendo il busto verticale, poi risali spingendo con i talloni.', video: yt('front squat') },
      { name: 'Burpees', sets: '4×15', how: 'Dalla posizione eretta scendi a terra, esegui un piegamento, richiama i piedi e salta in alto con le braccia tese sopra la testa.', video: yt('burpees esecuzione') },
      { name: 'Turkish get-up', sets: '3×5 per lato', how: 'Dal suolo, con il peso sopra la spalla, alzati passando per gomito, mano, ponte e affondo mantenendo sempre il braccio verticale e lo sguardo sul peso.', video: yt('turkish get up') },
    ],
  },
  {
    _id: 'sch-005', category: 'schede', name: 'Piano BOXE — Retsu Kaioh', price: 27.9,
    art: 'boxing', tags: ['boxe', 'condizionamento'], stock: 999, level: 'Intermedio', duration: '8 settimane',
    description: 'Tecnica di pugilato e condizionamento marziale. Colpisci come un maestro del Kaioh.',
    exercises: [
      { name: 'Jab diretto', sets: '10×30"', how: 'Guardia alta, parti dal braccio avanzato. Estendi il pugno in linea retta ruotando leggermente il polso a fine colpo e richiama subito la mano in guardia.', video: yt('jab pugilato tecnica') },
      { name: 'Gancio', sets: '10×30"', how: 'Ruota il piede e l\'anca dello stesso lato del braccio che colpisce, gomito a 90°, e porta il pugno lateralmente mantenendo l\'altra mano a protezione del volto.', video: yt('gancio boxe tecnica') },
      { name: 'Salto della corda', sets: '5×3\'', how: 'Salti bassi e rapidi sull\'avampiede, polsi che ruotano la corda, gomiti vicini al corpo. Mantieni un ritmo costante.', video: yt('salto della corda boxe') },
      { name: 'Shadow boxing', sets: '5×3\'', how: 'Combatti contro un avversario immaginario alternando colpi e schivate, curando movimento dei piedi e ritorno in guardia dopo ogni colpo.', video: yt('shadow boxing') },
    ],
  },
  {
    _id: 'sch-006', category: 'schede', name: 'Piano MOBILITÀ — Kaku Kaioh', price: 17.9,
    art: 'mobility', tags: ['mobilità', 'recupero'], stock: 999, level: 'Tutti i livelli', duration: '4 settimane',
    description: 'Mobilità articolare e prevenzione infortuni. Un corpo che non si muove bene non può diventare forte.',
    exercises: [
      { name: 'Mobilità anche 90/90', sets: '3×10 per lato', how: 'Seduto con entrambe le ginocchia a 90°, ruota il bacino da un lato all\'altro mantenendo il busto eretto e i piedi a terra.', video: yt('mobilità anche 90 90') },
      { name: 'Cat-cow', sets: '3×12', how: 'A quattro zampe, alterna inarcamento e incurvamento della colonna sincronizzando il respiro: inspira in estensione, espira in flessione.', video: yt('cat cow esercizio') },
      { name: 'Dislocazioni con bastone', sets: '3×12', how: 'Impugna un bastone largo davanti a te e portalo dietro la schiena a braccia tese, riducendo gradualmente la larghezza della presa.', video: yt('shoulder dislocates bastone') },
      { name: 'Squat profondo isometrico', sets: '3×45"', how: 'Scendi nella posizione più bassa dello squat con i talloni a terra e resta lì, spingendo i gomiti contro le ginocchia per aprire le anche.', video: yt('deep squat hold mobilità') },
    ],
  },
  {
    _id: 'sch-007', category: 'schede', name: 'Piano HOME WORKOUT — Zero Attrezzi', price: 14.9,
    art: 'home', tags: ['casa', 'principiante'], stock: 999, level: 'Principiante', duration: '4 settimane',
    description: 'Allenati ovunque, senza attrezzi. Nessuna palestra, nessuna scusa: solo tu e il pavimento.',
    exercises: [
      { name: 'Squat a corpo libero', sets: '4×20', how: 'Piedi larghezza spalle, braccia avanti per bilanciare. Scendi spingendo i fianchi indietro fino a coscia parallela, poi risali contraendo i glutei.', video: yt('squat a corpo libero') },
      { name: 'Piegamenti sulle ginocchia', sets: '4×12', how: 'Variante facilitata: appoggia le ginocchia a terra mantenendo il corpo in linea da testa a ginocchia e scendi con il petto verso il pavimento.', video: yt('piegamenti sulle ginocchia') },
      { name: 'Glute bridge', sets: '3×20', how: 'Supino, ginocchia piegate e piedi a terra. Solleva il bacino contraendo i glutei fino ad allineare spalle-anche-ginocchia, poi scendi senza appoggiare del tutto.', video: yt('glute bridge') },
      { name: 'Mountain climber', sets: '4×40"', how: 'In posizione di plank alto, porta alternativamente le ginocchia verso il petto mantenendo il bacino basso e stabile.', video: yt('mountain climber') },
    ],
  },

  // ---------------- PROTEINE ----------------
  {
    _id: 'pro-001', category: 'proteine', name: 'Whey Isolate DEMON — Cioccolato', price: 39.9,
    art: 'tub-choco', tags: ['whey', 'isolate'], stock: 120,
    description: '2 kg di proteine isolate del siero, 27g per dose. Recupero da combattente.',
    usage: 'Sciogli 1 misurino (30g) in 250-300 ml di acqua o latte vegetale. Assumi subito dopo l\'allenamento oppure per completare il fabbisogno proteico giornaliero.',
  },
  {
    _id: 'pro-002', category: 'proteine', name: 'Whey Concentrate OGRE — Vaniglia', price: 29.9,
    art: 'tub-vanilla', tags: ['whey'], stock: 150,
    description: '2 kg concentrato, gusto vaniglia. Il carburante quotidiano del guerriero.',
    usage: 'Sciogli 1 misurino (30g) in 300 ml di liquido. Ideale a colazione o nel post-workout.',
  },
  {
    _id: 'pro-003', category: 'proteine', name: 'Vegan Protein SHADOW — Cacao', price: 34.9,
    art: 'pouch', tags: ['vegan'], stock: 80,
    description: 'Proteine vegetali (pisello + riso), 24g per dose. Forza senza compromessi.',
    usage: 'Sciogli 1 misurino (32g) in 350 ml di bevanda vegetale. Ottimo anche frullato con banana e avena.',
  },
  {
    _id: 'pro-004', category: 'proteine', name: 'Caseine NIGHT FANG', price: 32.9,
    art: 'tub-night', tags: ['caseine', 'notte'], stock: 70,
    description: 'Caseine micellari a rilascio lento: nutrono il muscolo per tutta la notte.',
    usage: 'Sciogli 1 misurino (30g) in 250 ml di liquido 30 minuti prima di coricarti.',
  },
  {
    _id: 'pro-005', category: 'proteine', name: 'Protein Bar FIST — box 12', price: 24.9,
    art: 'bar', tags: ['snack', 'barrette'], stock: 200,
    description: '12 barrette da 20g di proteine. Lo spuntino del combattente, ovunque tu sia.',
    usage: 'Consuma 1 barretta come spuntino o nel pre/post allenamento.',
  },

  // ---------------- INTEGRATORI ----------------
  {
    _id: 'int-001', category: 'integratori', name: 'Creatina MONSTER Monoidrato', price: 19.9,
    art: 'creatine', tags: ['creatina'], stock: 200,
    description: 'Creatina monoidrato micronizzata 500g. Forza esplosiva, dose 5g/die.',
    usage: 'Assumi 5g al giorno, tutti i giorni, sciolti in acqua o succo. Non serve fase di carico: la costanza è tutto.',
  },
  {
    _id: 'int-002', category: 'integratori', name: 'Pre-Workout RAGE', price: 27.9,
    art: 'preworkout', tags: ['pre-workout', 'caffeina'], stock: 90,
    description: 'Pre-workout con caffeina, beta-alanina e citrullina. Entra nell\'arena carico a mille.',
    usage: 'Sciogli 1 misurino in 300 ml d\'acqua 20-30 minuti prima dell\'allenamento. Evita l\'assunzione serale.',
  },
  {
    _id: 'int-003', category: 'integratori', name: 'BCAA RECOVER 2:1:1', price: 22.9,
    art: 'bcaa', tags: ['bcaa', 'recupero'], stock: 110,
    description: 'Aminoacidi ramificati per il recupero. Torna più forte ad ogni allenamento.',
    usage: 'Assumi 5-10g durante o subito dopo l\'allenamento, sciolti in acqua.',
  },
  {
    _id: 'int-004', category: 'integratori', name: 'Omega-3 IRON Fish Oil', price: 16.9,
    art: 'omega', tags: ['omega3', 'salute'], stock: 130,
    description: 'Olio di pesce EPA/DHA, 120 softgel. Articolazioni e cuore da combattente.',
    usage: 'Assumi 2 softgel al giorno durante i pasti principali.',
  },
  {
    _id: 'int-005', category: 'integratori', name: 'ZMA NIGHT RECOVERY', price: 18.9,
    art: 'zma', tags: ['zma', 'sonno'], stock: 95,
    description: 'Zinco, magnesio e vitamina B6: sonno profondo e recupero notturno.',
    usage: 'Assumi 3 capsule 30 minuti prima di dormire, lontano dai latticini.',
  },
  {
    _id: 'int-006', category: 'integratori', name: 'Elettroliti ARENA SALT', price: 13.9,
    art: 'electrolytes', tags: ['idratazione'], stock: 140,
    description: 'Sali minerali per sessioni lunghe e sudate. Non crollare a metà battaglia.',
    usage: 'Sciogli 1 bustina in 500 ml d\'acqua durante l\'allenamento o nelle giornate calde.',
  },

  // ---------------- ATTREZZATURA ----------------
  {
    _id: 'att-001', category: 'attrezzatura', name: 'Corda da salto SPEED DEMON', price: 14.9,
    art: 'rope', tags: ['cardio', 'boxe'], stock: 160,
    description: 'Corda in acciaio rivestito con cuscinetti rapidi. Il cardio dei pugili.',
    usage: 'Regola la lunghezza: in piedi al centro della corda, le impugnature devono arrivare alle ascelle.',
  },
  {
    _id: 'att-002', category: 'attrezzatura', name: 'Elastici RESISTANCE OGRE — set 5', price: 24.9,
    art: 'bands', tags: ['elastici', 'casa'], stock: 120,
    description: 'Set di 5 bande da 5 a 60 kg. Allenamento completo che sta in uno zaino.',
    usage: 'Scegli la banda in base alla resistenza desiderata; controlla sempre la fase negativa del movimento.',
  },
  {
    _id: 'att-003', category: 'attrezzatura', name: 'Guanti da presa GRIP FANG', price: 19.9,
    art: 'gloves', tags: ['presa', 'palestra'], stock: 100,
    description: 'Guanti con palmo antiscivolo e fascia da polso. La presa non cede mai.',
    usage: 'Indossali nelle trazioni e nei tirate pesanti per proteggere i palmi e stabilizzare il polso.',
  },
  {
    _id: 'att-004', category: 'attrezzatura', name: 'Shaker ARENA 900 ml', price: 9.9,
    art: 'shaker', tags: ['accessori'], stock: 250,
    description: 'Shaker con griglia frullante e scala graduata. Zero grumi, solo proteine.',
    usage: 'Aggiungi prima il liquido e poi la polvere, poi agita 10 secondi. Lavalo subito dopo l\'uso.',
  },
  {
    _id: 'att-005', category: 'attrezzatura', name: 'Anelli da ginnastica RINGS OF WAR', price: 39.9,
    art: 'rings', tags: ['calisthenics', 'anelli'], stock: 60,
    description: 'Anelli in legno con cinghie regolabili. Il calisthenics al livello successivo.',
    usage: 'Fissali a una barra stabile e regola l\'altezza; inizia con esercizi bassi per abituare le spalle all\'instabilità.',
  },
];

const COUPONS = [
  { code: 'BAKI20', type: 'percent', value: 20, active: 1, expires_at: null },
  { code: 'YUJIRO10', type: 'percent', value: 10, active: 1, expires_at: null },
  { code: 'ARENA5', type: 'fixed', value: 5, active: 1, expires_at: null },
  { code: 'AMINUP15', type: 'percent', value: 15, active: 1, expires_at: null },
  { code: 'SCADUTO', type: 'percent', value: 50, active: 1, expires_at: '2020-01-01' },
];

export async function seed() {
  // Prodotti (NoSQL) — upsert
  for (const p of CATALOG) {
    await products.updateAsync({ _id: p._id }, p, { upsert: true });
  }
  // Rimuove eventuali prodotti non più a catalogo
  const ids = CATALOG.map((p) => p._id);
  await products.removeAsync({ _id: { $nin: ids } }, { multi: true });
  console.log(`[seed] ${CATALOG.length} prodotti inseriti/aggiornati (NeDB).`);

  // Coupon (SQL)
  const stmt = db.prepare(
    `INSERT INTO coupons (code, type, value, active, expires_at)
     VALUES (@code, @type, @value, @active, @expires_at)
     ON CONFLICT(code) DO UPDATE SET
       type=excluded.type, value=excluded.value,
       active=excluded.active, expires_at=excluded.expires_at`
  );
  const tx = transaction((rows) => rows.forEach((r) => stmt.run(r)));
  tx(COUPONS);
  console.log(`[seed] ${COUPONS.length} coupon inseriti/aggiornati (SQLite).`);

  // Promozione a venditore tramite variabile d'ambiente (opzionale)
  const sellerEmail = (process.env.SELLER_EMAIL || '').toLowerCase().trim();
  if (sellerEmail) {
    const r = db.prepare('UPDATE users SET role = ? WHERE email = ?').run('seller', sellerEmail);
    console.log(r.changes
      ? `[seed] ${sellerEmail} promosso a venditore.`
      : `[seed] Nessun utente con email ${sellerEmail}: registralo e rilancia il seed.`);
  }

  console.log('[seed] Completato. Coupon di test: BAKI20 (20%), AMINUP15 (15%), ARENA5 (-5€).');
}

// Auto-esecuzione solo quando lanciato direttamente (`npm run seed`),
// così l'import dai test non termina il processo.
if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
  seed().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
}
