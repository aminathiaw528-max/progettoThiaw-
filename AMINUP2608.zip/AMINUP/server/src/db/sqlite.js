import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { mkdirSync } from 'node:fs';

// SQLite integrato in Node (node:sqlite) — nessuna dipendenza nativa da compilare.
const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, '..', '..', 'data');
mkdirSync(dataDir, { recursive: true });

export const db = new DatabaseSync(join(dataDir, 'aminta.sqlite'));
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

/**
 * Helper transazione (equivalente a better-sqlite3 db.transaction):
 * ritorna una funzione che esegue `fn` dentro BEGIN/COMMIT, con ROLLBACK su errore.
 */
export function transaction(fn) {
  return (...args) => {
    db.exec('BEGIN');
    try {
      const result = fn(...args);
      db.exec('COMMIT');
      return result;
    } catch (e) {
      db.exec('ROLLBACK');
      throw e;
    }
  };
}

// Schema relazionale (SQL). Creazione idempotente.
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'customer',  -- customer | seller
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  status      TEXT NOT NULL DEFAULT 'pending',   -- pending | paid
  subtotal    REAL NOT NULL,
  discount    REAL NOT NULL DEFAULT 0,
  total       REAL NOT NULL,
  coupon_code TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL,
  name       TEXT NOT NULL,
  price      REAL NOT NULL,
  qty        INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id       INTEGER NOT NULL REFERENCES orders(id),
  user_id        INTEGER NOT NULL REFERENCES users(id),
  method         TEXT NOT NULL,                 -- card | applepay | coupon
  amount         REAL NOT NULL,
  status         TEXT NOT NULL,                 -- succeeded | failed
  card_last4     TEXT,
  card_encrypted TEXT,                          -- blob AES-256-GCM (mai in chiaro)
  transaction_id TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Carrello persistente lato server (una riga per prodotto per utente)
CREATE TABLE IF NOT EXISTS cart_items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  product_id TEXT NOT NULL,
  name       TEXT NOT NULL,
  price      REAL NOT NULL,
  image      TEXT,
  qty        INTEGER NOT NULL DEFAULT 1,
  UNIQUE(user_id, product_id)
);

CREATE TABLE IF NOT EXISTS coupons (
  code       TEXT PRIMARY KEY,
  type       TEXT NOT NULL,   -- percent | fixed
  value      REAL NOT NULL,
  active     INTEGER NOT NULL DEFAULT 1,
  expires_at TEXT
);
`);

/**
 * Migrazioni leggere: aggiunge colonne mancanti a DB già esistenti,
 * così i dati creati nelle sessioni precedenti non vanno persi.
 */
function addColumnIfMissing(table, column, definition) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
  if (!cols.includes(column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    console.log(`[db] migrazione: aggiunta colonna ${table}.${column}`);
  }
}
addColumnIfMissing('users', 'role', "TEXT NOT NULL DEFAULT 'customer'");
addColumnIfMissing('orders', 'updated_at', 'TEXT');

export default db;
