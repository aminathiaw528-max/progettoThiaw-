import Datastore from '@seald-io/nedb';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { mkdirSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, '..', '..', 'data');
mkdirSync(dataDir, { recursive: true });

// NoSQL (documentale): catalogo prodotti a schema flessibile
export const products = new Datastore({
  filename: join(dataDir, 'products.db'),
  autoload: true,
});

// NoSQL: log attività append-only (registrazioni, login, acquisti...)
export const activityLogs = new Datastore({
  filename: join(dataDir, 'activity.db'),
  autoload: true,
});

export async function logActivity(type, payload = {}) {
  try {
    await activityLogs.insertAsync({ type, ...payload, at: new Date().toISOString() });
  } catch {
    /* logging non deve mai bloccare la richiesta */
  }
}
