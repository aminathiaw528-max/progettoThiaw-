/**
 * Express 4 non intercetta le Promise rifiutate negli handler async:
 * l'errore diventa un "unhandledRejection" e in Node 24 abbatte il processo.
 * Questo wrapper inoltra l'errore al gestore errori di Express (→ 500 pulito).
 */
export const ah = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export default ah;
