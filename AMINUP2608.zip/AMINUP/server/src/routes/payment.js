import { Router } from 'express';
import { ah } from '../utils/asyncHandler.js';
import db, { transaction } from '../db/sqlite.js';
import { logActivity } from '../db/nedb.js';
import { requireAuth } from '../middleware/auth.js';
import { processPayment } from '../services/payment.js';
import { evaluateCoupon } from './coupons.js';
import { sendReceiptEmail } from '../services/email.js';

const router = Router();

// POST /api/payment/checkout
// body: { method: 'card'|'applepay'|'coupon', couponCode?, card?: { number, exp, cvc } }
router.post('/checkout', requireAuth, ah(async (req, res) => {
  const { method = 'card', couponCode, card } = req.body || {};

  const cartItems = db.prepare('SELECT * FROM cart_items WHERE user_id = ?').all(req.user.id);
  if (cartItems.length === 0) return res.status(400).json({ error: 'Il carrello è vuoto' });

  const subtotal = Number(
    cartItems.reduce((s, i) => s + i.price * i.qty, 0).toFixed(2)
  );

  // Coupon (opzionale)
  const couponRes = evaluateCoupon(couponCode, subtotal);
  if (!couponRes.ok) return res.status(422).json({ error: couponRes.error });
  const discount = couponRes.discount || 0;
  const total = Number((subtotal - discount).toFixed(2));

  // Elabora pagamento (cifratura AES-256-GCM dei dati carta)
  const pay = processPayment({ method, amount: total, card });
  if (pay.status !== 'succeeded') {
    return res.status(402).json({ error: pay.error || 'Pagamento rifiutato' });
  }

  // Persistenza transazionale: ordine + righe + pagamento
  const userRow = db.prepare('SELECT id, name, email FROM users WHERE id = ?').get(req.user.id);
  const createAll = transaction(() => {
    const orderInfo = db.prepare(
      `INSERT INTO orders (user_id, status, subtotal, discount, total, coupon_code)
       VALUES (?, 'paid', ?, ?, ?, ?)`
    ).run(req.user.id, subtotal, discount, total, couponRes.coupon?.code || null);
    const orderId = orderInfo.lastInsertRowid;

    const itemStmt = db.prepare(
      'INSERT INTO order_items (order_id, product_id, name, price, qty) VALUES (?, ?, ?, ?, ?)'
    );
    for (const i of cartItems) itemStmt.run(orderId, i.product_id, i.name, i.price, i.qty);

    db.prepare(
      `INSERT INTO payments (order_id, user_id, method, amount, status, card_last4, card_encrypted, transaction_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(orderId, req.user.id, method, total, pay.status, pay.cardLast4 || null,
      pay.cardEncrypted || null, pay.transactionId);

    // Svuota il carrello
    db.prepare('DELETE FROM cart_items WHERE user_id = ?').run(req.user.id);
    return orderId;
  });

  const orderId = createAll();
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(orderId);

  await logActivity('purchase', { userId: req.user.id, orderId, total, method });

  // Email ricevuta (non blocca la risposta)
  let emailPreview = null;
  try {
    const r = await sendReceiptEmail(userRow, order, items);
    emailPreview = r.preview;
  } catch (e) {
    console.error('[payment] invio ricevuta fallito:', e.message);
  }

  res.status(201).json({ order, items, transactionId: pay.transactionId, emailPreview });
}));

export default router;
