import { Router } from 'express';
import { ah } from '../utils/asyncHandler.js';
import { products } from '../db/nedb.js';
import db from '../db/sqlite.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

// GET /api/products?category=schede|proteine|integratori
router.get('/', ah(async (req, res) => {
  const query = {};
  if (req.query.category) query.category = req.query.category;
  const list = await products.findAsync(query).sort({ category: 1, price: 1 });
  res.json({ products: list });
}));

/**
 * GET /api/products/:id/guide
 * Guida "come si esegue": disponibile SOLO se l'utente ha effettivamente
 * acquistato (ordine pagato) quel prodotto.
 */
router.get('/:id/guide', requireAuth, ah(async (req, res) => {
  const purchased = db.prepare(
    `SELECT 1 FROM order_items oi
       JOIN orders o ON o.id = oi.order_id
      WHERE o.user_id = ? AND oi.product_id = ? AND o.status <> 'pending'
      LIMIT 1`
  ).get(req.user.id, req.params.id);

  if (!purchased) {
    return res.status(403).json({ error: 'Guida disponibile solo dopo l\'acquisto di questo prodotto' });
  }

  const product = await products.findOneAsync({ _id: req.params.id });
  if (!product) return res.status(404).json({ error: 'Prodotto non trovato' });

  res.json({
    product: {
      _id: product._id, name: product.name, category: product.category,
      art: product.art, level: product.level, duration: product.duration,
      description: product.description,
    },
    exercises: product.exercises || [],
    usage: product.usage || null,
  });
}));

// GET /api/products/:id
router.get('/:id', ah(async (req, res) => {
  const product = await products.findOneAsync({ _id: req.params.id });
  if (!product) return res.status(404).json({ error: 'Prodotto non trovato' });
  res.json({ product });
}));

export default router;
