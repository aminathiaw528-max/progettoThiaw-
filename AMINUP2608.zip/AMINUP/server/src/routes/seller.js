import { Router } from 'express';
import db from '../db/sqlite.js';
import { requireAuth, requireSeller } from '../middleware/auth.js';
import { logActivity } from '../db/nedb.js';

const router = Router();
router.use(requireAuth);

// Ciclo di vita di un ordine dopo il pagamento
export const ORDER_FLOW = ['paid', 'processing', 'shipped', 'completed'];
const LABELS = {
  paid: 'Ricevuti',
  processing: 'Da consegnare',
  shipped: 'Spediti',
  completed: 'Passati / Completati',
};

/**
 * POST /api/seller/bootstrap
 * Promuove l'utente corrente a venditore SOLO se non esiste ancora nessun venditore
 * (comodo per la demo: il primo che rivendica l'area diventa il gestore dello shop).
 */
router.post('/bootstrap', (req, res) => {
  const existing = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'seller'").get();
  if (existing.n > 0) {
    const me = db.prepare('SELECT role FROM users WHERE id = ?').get(req.user.id);
    if (me?.role === 'seller') return res.json({ role: 'seller', alreadySeller: true });
    return res.status(409).json({ error: 'Esiste già un venditore per questo shop' });
  }
  db.prepare("UPDATE users SET role = 'seller' WHERE id = ?").run(req.user.id);
  logActivity('seller_bootstrap', { userId: req.user.id });
  res.json({ role: 'seller' });
});

// Da qui in poi serve il ruolo venditore
router.use(requireSeller);

// GET /api/seller/orders — tutti gli ordini raggruppati per stato
router.get('/orders', (req, res) => {
  const rows = db.prepare(
    `SELECT o.*, u.name AS customer_name, u.email AS customer_email
       FROM orders o JOIN users u ON u.id = o.user_id
      WHERE o.status <> 'pending'
      ORDER BY datetime(o.created_at) DESC, o.id DESC`
  ).all();

  const orders = rows.map((o) => ({
    ...o,
    items: db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(o.id),
    payment: db.prepare(
      `SELECT method, amount, status, card_last4, transaction_id, created_at
         FROM payments WHERE order_id = ?`
    ).get(o.id),
  }));

  const groups = {};
  for (const s of ORDER_FLOW) {
    groups[s] = { label: LABELS[s], orders: orders.filter((o) => o.status === s) };
  }
  res.json({ orders, groups, flow: ORDER_FLOW });
});

// PATCH /api/seller/orders/:id/status  { status }
router.patch('/orders/:id/status', (req, res) => {
  const { status } = req.body || {};
  if (!ORDER_FLOW.includes(status)) {
    return res.status(422).json({ error: `Stato non valido. Ammessi: ${ORDER_FLOW.join(', ')}` });
  }
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Ordine non trovato' });
  if (order.status === 'pending') {
    return res.status(409).json({ error: 'Ordine non ancora pagato' });
  }

  db.prepare("UPDATE orders SET status = ?, updated_at = datetime('now') WHERE id = ?")
    .run(status, order.id);
  logActivity('order_status', { orderId: order.id, from: order.status, to: status });
  res.json({ order: db.prepare('SELECT * FROM orders WHERE id = ?').get(order.id) });
});

// GET /api/seller/stats — metriche finanziarie e di vendita
router.get('/stats', (req, res) => {
  const paidFilter = "status <> 'pending'";

  const totals = db.prepare(
    `SELECT COUNT(*) AS orders, COALESCE(SUM(total),0) AS revenue,
            COALESCE(SUM(discount),0) AS discounts, COALESCE(AVG(total),0) AS avgOrder
       FROM orders WHERE ${paidFilter}`
  ).get();

  const itemsSold = db.prepare(
    `SELECT COALESCE(SUM(oi.qty),0) AS n
       FROM order_items oi JOIN orders o ON o.id = oi.order_id
      WHERE o.${paidFilter}`
  ).get();

  const last7 = db.prepare(
    `SELECT COALESCE(SUM(total),0) AS revenue, COUNT(*) AS orders
       FROM orders
      WHERE ${paidFilter} AND datetime(created_at) >= datetime('now', '-7 days')`
  ).get();

  const byStatus = db.prepare(
    `SELECT status, COUNT(*) AS n, COALESCE(SUM(total),0) AS revenue
       FROM orders WHERE ${paidFilter} GROUP BY status`
  ).all();

  const topProducts = db.prepare(
    `SELECT oi.product_id, oi.name, SUM(oi.qty) AS qty, SUM(oi.qty * oi.price) AS revenue
       FROM order_items oi JOIN orders o ON o.id = oi.order_id
      WHERE o.${paidFilter}
      GROUP BY oi.product_id, oi.name
      ORDER BY qty DESC, revenue DESC
      LIMIT 5`
  ).all();

  const byDay = db.prepare(
    `SELECT date(created_at) AS day, COALESCE(SUM(total),0) AS revenue, COUNT(*) AS orders
       FROM orders
      WHERE ${paidFilter} AND datetime(created_at) >= datetime('now', '-14 days')
      GROUP BY date(created_at) ORDER BY day`
  ).all();

  const customers = db.prepare(
    `SELECT COUNT(DISTINCT user_id) AS n FROM orders WHERE ${paidFilter}`
  ).get();

  res.json({
    revenue: Number(totals.revenue.toFixed(2)),
    orders: totals.orders,
    avgOrder: Number(totals.avgOrder.toFixed(2)),
    discounts: Number(totals.discounts.toFixed(2)),
    itemsSold: itemsSold.n,
    customers: customers.n,
    last7: { revenue: Number(last7.revenue.toFixed(2)), orders: last7.orders },
    byStatus, topProducts, byDay,
  });
});

export default router;
