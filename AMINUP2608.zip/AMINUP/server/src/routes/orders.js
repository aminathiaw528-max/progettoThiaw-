import { Router } from 'express';
import db from '../db/sqlite.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

// GET /api/orders — storico ordini + pagamenti dell'utente
router.get('/', (req, res) => {
  const orders = db.prepare(
    'SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC, id DESC'
  ).all(req.user.id);

  const detailed = orders.map((o) => {
    const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(o.id);
    // Non esponiamo mai il blob cifrato della carta al client
    const payment = db.prepare(
      `SELECT method, amount, status, card_last4, transaction_id, created_at
       FROM payments WHERE order_id = ?`
    ).get(o.id);
    return { ...o, items, payment };
  });

  res.json({ orders: detailed });
});

// GET /api/orders/:id
router.get('/:id', (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user.id);
  if (!order) return res.status(404).json({ error: 'Ordine non trovato' });
  const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
  const payment = db.prepare(
    `SELECT method, amount, status, card_last4, transaction_id, created_at
     FROM payments WHERE order_id = ?`
  ).get(order.id);
  res.json({ order: { ...order, items, payment } });
});

export default router;
