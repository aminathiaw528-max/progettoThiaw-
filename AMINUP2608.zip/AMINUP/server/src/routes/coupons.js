import { Router } from 'express';
import db from '../db/sqlite.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

/**
 * Valida un coupon e calcola lo sconto su un subtotale.
 * @returns {{ ok:boolean, error?:string, coupon?:object, discount?:number }}
 */
export function evaluateCoupon(code, subtotal) {
  if (!code) return { ok: true, discount: 0, coupon: null };
  const c = db.prepare('SELECT * FROM coupons WHERE code = ?').get(String(code).toUpperCase().trim());
  if (!c) return { ok: false, error: 'Coupon inesistente' };
  if (!c.active) return { ok: false, error: 'Coupon non attivo' };
  if (c.expires_at && new Date(c.expires_at) < new Date()) {
    return { ok: false, error: 'Coupon scaduto' };
  }
  let discount = c.type === 'percent' ? (subtotal * c.value) / 100 : c.value;
  discount = Math.min(discount, subtotal); // non si scende sotto zero
  return { ok: true, coupon: c, discount: Number(discount.toFixed(2)) };
}

// POST /api/coupons/validate  { code, subtotal }
router.post('/validate', requireAuth, (req, res) => {
  const { code, subtotal = 0 } = req.body || {};
  const result = evaluateCoupon(code, Number(subtotal) || 0);
  if (!result.ok) return res.status(422).json({ error: result.error });
  res.json({
    code: result.coupon?.code || null,
    discount: result.discount,
    total: Number(((Number(subtotal) || 0) - result.discount).toFixed(2)),
  });
});

export default router;
