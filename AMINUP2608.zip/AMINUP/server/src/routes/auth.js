import { Router } from 'express';
import { ah } from '../utils/asyncHandler.js';
import bcrypt from 'bcryptjs';
import db from '../db/sqlite.js';
import { logActivity } from '../db/nedb.js';
import { signToken, requireAuth } from '../middleware/auth.js';
import {
  sendWelcomeEmail, emailDomainExists, isValidEmailFormat,
} from '../services/email.js';

const router = Router();

// POST /api/auth/register
router.post('/register', ah(async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Nome, email e password sono obbligatori' });
  }
  if (!isValidEmailFormat(email)) {
    return res.status(422).json({ error: 'Formato email non valido' });
  }
  if (String(password).length < 6) {
    return res.status(422).json({ error: 'La password deve avere almeno 6 caratteri' });
  }
  // Requisito: la mail deve esistere davvero (record MX del dominio)
  const exists = await emailDomainExists(email);
  if (!exists) {
    return res.status(422).json({ error: 'Il dominio email non esiste: usa una mail reale' });
  }

  const emailNorm = String(email).toLowerCase().trim();
  const already = db.prepare('SELECT id FROM users WHERE email = ?').get(emailNorm);
  if (already) return res.status(409).json({ error: 'Email già registrata' });

  const password_hash = bcrypt.hashSync(password, 10);
  const info = db
    .prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)')
    .run(name.trim(), emailNorm, password_hash);

  const user = { id: info.lastInsertRowid, name: name.trim(), email: emailNorm, role: 'customer' };
  await logActivity('register', { userId: user.id, email: user.email });

  // Email di benvenuto (non blocca la risposta se fallisce)
  let emailPreview = null;
  try {
    const r = await sendWelcomeEmail(user);
    emailPreview = r.preview;
  } catch (e) {
    console.error('[auth] invio mail benvenuto fallito:', e.message);
  }

  const token = signToken(user);
  res.status(201).json({ token, user, emailPreview });
}));

// POST /api/auth/login
router.post('/login', ah(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email e password richieste' });

  const emailNorm = String(email).toLowerCase().trim();
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(emailNorm);
  if (!row || !bcrypt.compareSync(password, row.password_hash)) {
    return res.status(401).json({ error: 'Credenziali non valide' });
  }
  const user = { id: row.id, name: row.name, email: row.email, role: row.role || 'customer' };
  await logActivity('login', { userId: user.id });
  res.json({ token: signToken(user), user });
}));

// GET /api/auth/me
router.get('/me', requireAuth, (req, res) => {
  const row = db.prepare('SELECT id, name, email, role, created_at FROM users WHERE id = ?').get(req.user.id);
  if (!row) return res.status(404).json({ error: 'Utente non trovato' });
  res.json({ user: row });
});

export default router;
