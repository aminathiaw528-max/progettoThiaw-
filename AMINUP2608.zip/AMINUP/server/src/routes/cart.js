import { Router } from 'express';
import { ah } from '../utils/asyncHandler.js';
import db from '../db/sqlite.js';
import { products } from '../db/nedb.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

function getCart(userId) {
  return db.prepare('SELECT * FROM cart_items WHERE user_id = ? ORDER BY id').all(userId);
}

// GET /api/cart
router.get('/', (req, res) => {
  res.json({ items: getCart(req.user.id) });
});

// POST /api/cart/items  { productId, qty }
router.post('/items', ah(async (req, res) => {
  const { productId, qty = 1 } = req.body || {};
  const product = await products.findOneAsync({ _id: productId });
  if (!product) return res.status(404).json({ error: 'Prodotto non trovato' });

  const q = Math.max(1, Number(qty) || 1);
  db.prepare(
    `INSERT INTO cart_items (user_id, product_id, name, price, image, qty)
     VALUES (@user_id, @product_id, @name, @price, @image, @qty)
     ON CONFLICT(user_id, product_id)
       DO UPDATE SET qty = qty + excluded.qty`
  ).run({
    user_id: req.user.id, product_id: product._id, name: product.name,
    price: product.price,
    // la colonna `image` conserva la chiave dell'illustrazione (`art`) del prodotto
    image: product.art || product.image || null,
    qty: q,
  });
  res.status(201).json({ items: getCart(req.user.id) });
}));

// PATCH /api/cart/items/:id  { qty }
router.patch('/items/:id', (req, res) => {
  const qty = Math.max(1, Number(req.body?.qty) || 1);
  const r = db.prepare('UPDATE cart_items SET qty = ? WHERE id = ? AND user_id = ?')
    .run(qty, req.params.id, req.user.id);
  if (r.changes === 0) return res.status(404).json({ error: 'Item non trovato' });
  res.json({ items: getCart(req.user.id) });
});

// DELETE /api/cart/items/:id
router.delete('/items/:id', (req, res) => {
  db.prepare('DELETE FROM cart_items WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.json({ items: getCart(req.user.id) });
});

export default router;
