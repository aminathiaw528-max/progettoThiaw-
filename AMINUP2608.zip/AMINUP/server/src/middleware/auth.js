import jwt from 'jsonwebtoken';
import { config } from '../config.js';

import db from '../db/sqlite.js';

export function signToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, name: user.name, role: user.role || 'customer' },
    config.jwtSecret,
    { expiresIn: '7d' }
  );
}

/**
 * Richiede il ruolo 'seller'. Il ruolo è letto dal DB (non dal token),
 * così una promozione ha effetto subito senza dover rifare il login.
 */
export function requireSeller(req, res, next) {
  const row = db.prepare('SELECT role FROM users WHERE id = ?').get(req.user.id);
  if (!row || row.role !== 'seller') {
    return res.status(403).json({ error: 'Accesso riservato ai venditori' });
  }
  next();
}

// Middleware: richiede un JWT valido nell'header Authorization: Bearer <token>
export function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Autenticazione richiesta' });
  try {
    req.user = jwt.verify(token, config.jwtSecret);
    next();
  } catch {
    return res.status(401).json({ error: 'Token non valido o scaduto' });
  }
}
