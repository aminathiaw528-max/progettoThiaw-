import 'dotenv/config';
import crypto from 'node:crypto';

// Se la chiave AES non è impostata (o è il placeholder), ne generiamo una effimera
// per lo sviluppo così il server parte comunque. In produzione impostala in .env.
let cardKeyHex = process.env.CARD_ENC_KEY || '';
if (!/^[0-9a-fA-F]{64}$/.test(cardKeyHex)) {
  cardKeyHex = crypto.randomBytes(32).toString('hex');
  console.warn('[config] CARD_ENC_KEY mancante/non valida: uso una chiave effimera di sviluppo.');
}

export const config = {
  port: Number(process.env.PORT) || 4000,
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  jwtSecret: process.env.JWT_SECRET || 'dev-secret',
  cardEncKey: Buffer.from(cardKeyHex, 'hex'),
  email: {
    mode: process.env.EMAIL_MODE || 'ethereal',
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 465,
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
    from: process.env.MAIL_FROM || 'AMINUP <no-reply@aminup.dev>',
  },
  verifyEmailMx: (process.env.VERIFY_EMAIL_MX || 'true') === 'true',
};
