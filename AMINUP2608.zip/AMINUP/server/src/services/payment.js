import crypto from 'node:crypto';
import { config } from '../config.js';

/**
 * Layer di pagamento SIMULATO ma con cifratura REALE dei dati carta.
 * In produzione va sostituito con un PSP (Stripe/Adyen); l'interfaccia resta identica.
 */

// --- Cifratura AES-256-GCM del PAN (numero carta) ---
export function encryptCard(cardNumber) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', config.cardEncKey, iv);
  const encrypted = Buffer.concat([cipher.update(String(cardNumber), 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  // Formato salvato: iv:authTag:ciphertext (base64)
  return [iv.toString('base64'), authTag.toString('base64'), encrypted.toString('base64')].join(':');
}

export function decryptCard(blob) {
  const [ivB64, tagB64, dataB64] = blob.split(':');
  const decipher = crypto.createDecipheriv('aes-256-gcm', config.cardEncKey, Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]).toString('utf8');
}

// --- Validazione carta con algoritmo di Luhn ---
export function luhnValid(number) {
  const digits = String(number).replace(/\s+/g, '');
  if (!/^\d{12,19}$/.test(digits)) return false;
  let sum = 0;
  let alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = Number(digits[i]);
    if (alt) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
    alt = !alt;
  }
  return sum % 10 === 0;
}

/**
 * Elabora un pagamento di test.
 * @param {object} p
 * @param {'card'|'applepay'|'coupon'} p.method
 * @param {number} p.amount
 * @param {object} [p.card] { number, exp, cvc }
 * @returns {{ status, transactionId, cardLast4, cardEncrypted }}
 */
export function processPayment({ method, amount, card }) {
  const transactionId = 'txn_' + crypto.randomBytes(8).toString('hex');

  // Importo zero (es. coperto interamente da coupon): successo senza carta
  if (amount <= 0) {
    return { status: 'succeeded', transactionId, cardLast4: null, cardEncrypted: null };
  }

  if (method === 'coupon') {
    // "Solo coupon" ma resta un importo da pagare: serve un metodo reale
    return {
      status: 'failed',
      transactionId,
      error: 'Il coupon non copre l\'intero importo: scegli Carta o Apple Pay',
    };
  }

  if (method === 'applepay') {
    // Token Apple Pay simulato: passa comunque dallo stesso strato cifrato
    const fakeToken = 'AP_' + crypto.randomBytes(10).toString('hex');
    return {
      status: 'succeeded',
      transactionId,
      cardLast4: null,
      cardEncrypted: encryptCard(fakeToken),
    };
  }

  // method === 'card'
  if (!card || !luhnValid(card.number)) {
    return { status: 'failed', transactionId, error: 'Numero carta non valido' };
  }
  const digits = String(card.number).replace(/\s+/g, '');
  return {
    status: 'succeeded',
    transactionId,
    cardLast4: digits.slice(-4),
    cardEncrypted: encryptCard(digits), // PAN mai salvato in chiaro
  };
}
