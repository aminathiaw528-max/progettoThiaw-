import nodemailer from 'nodemailer';
import dns from 'node:dns/promises';
import { config } from '../config.js';

let transporterPromise = null;

async function getTransporter() {
  if (transporterPromise) return transporterPromise;

  transporterPromise = (async () => {
    if (config.email.mode === 'smtp' && config.email.host) {
      return nodemailer.createTransport({
        host: config.email.host,
        port: config.email.port,
        secure: config.email.port === 465,
        auth: { user: config.email.user, pass: config.email.pass },
      });
    }
    // Modalità Ethereal: account di test automatico, nessuna credenziale richiesta.
    const testAccount = await nodemailer.createTestAccount();
    console.log('[email] Modalità Ethereal attiva. Le email non arrivano davvero ma');
    console.log('        ogni invio produce un link di anteprima stampato in console.');
    return nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: { user: testAccount.user, pass: testAccount.pass },
    });
  })();

  return transporterPromise;
}

/**
 * Verifica che il dominio dell'email esista davvero (record MX).
 * Requisito: "la mail inserita deve essere esistente".
 */
export async function emailDomainExists(email) {
  if (!config.verifyEmailMx) return true;
  const domain = String(email).split('@')[1];
  if (!domain) return false;
  try {
    const mx = await dns.resolveMx(domain);
    if (mx && mx.length > 0) return true;
  } catch { /* prova fallback A record */ }
  try {
    const a = await dns.resolve(domain);
    return a && a.length > 0;
  } catch {
    return false;
  }
}

export function isValidEmailFormat(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email));
}

async function send(to, subject, html) {
  const transporter = await getTransporter();
  const info = await transporter.sendMail({ from: config.email.from, to, subject, html });
  const preview = nodemailer.getTestMessageUrl(info);
  if (preview) console.log(`[email] Anteprima "${subject}" → ${preview}`);
  return { messageId: info.messageId, preview: preview || null };
}

const shell = (title, body) => `
  <div style="font-family:Arial,sans-serif;background:#0a0608;color:#f4ecef;padding:24px">
    <div style="max-width:560px;margin:auto;border:1px solid #ff2e88;border-radius:12px;overflow:hidden">
      <div style="background:#ff2e88;color:#0a0608;padding:16px 24px;font-size:22px;font-weight:800;letter-spacing:1px">
        AMINUP <span style="color:#ffffff">// GET STRONGER</span>
      </div>
      <div style="padding:24px">
        <h2 style="color:#ff86bd;margin-top:0">${title}</h2>
        ${body}
        <p style="margin-top:24px;color:#888;font-size:12px">The strongest survive. — AMINUP</p>
      </div>
    </div>
  </div>`;

export async function sendWelcomeEmail(user) {
  return send(
    user.email,
    'Benvenuto nell\'arena, guerriero 💪',
    shell('Il tuo account è stato creato', `
      <p>Ciao <b>${user.name}</b>,</p>
      <p>Sei ufficialmente entrato in <b>AMINUP</b>. Schede di allenamento, proteine e integratori
      per diventare il più forte. Non mollare mai.</p>
      <p><b>"Un uomo che non si allena marcisce."</b></p>`)
  );
}

export async function sendReceiptEmail(user, order, items) {
  const rows = items.map(
    (i) => `<tr>
      <td style="padding:6px 0;border-bottom:1px solid #333">${i.name} × ${i.qty}</td>
      <td style="padding:6px 0;border-bottom:1px solid #333;text-align:right">€ ${(i.price * i.qty).toFixed(2)}</td>
    </tr>`
  ).join('');
  return send(
    user.email,
    `Pagamento ricevuto — Ordine #${order.id}`,
    shell('Pagamento ricevuto ✅', `
      <p>Ciao <b>${user.name}</b>, abbiamo ricevuto il tuo pagamento.</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0">
        ${rows}
        <tr><td style="padding:8px 0;color:#888">Sconto</td>
            <td style="padding:8px 0;text-align:right;color:#888">− € ${order.discount.toFixed(2)}</td></tr>
        <tr><td style="padding:8px 0;font-weight:800;color:#ff86bd">TOTALE</td>
            <td style="padding:8px 0;text-align:right;font-weight:800;color:#ff86bd">€ ${order.total.toFixed(2)}</td></tr>
      </table>
      <p>Ordine <b>#${order.id}</b> — stato: <b>${order.status}</b>.</p>
      <p>Ora vai ad allenarti. 🔥</p>`)
  );
}
