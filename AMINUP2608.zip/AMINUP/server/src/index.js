import express from 'express';
import cors from 'cors';
import { config } from './config.js';

import authRoutes from './routes/auth.js';
import productRoutes from './routes/products.js';
import cartRoutes from './routes/cart.js';
import couponRoutes from './routes/coupons.js';
import paymentRoutes from './routes/payment.js';
import orderRoutes from './routes/orders.js';
import sellerRoutes from './routes/seller.js';

const app = express();

app.use(cors({ origin: config.clientOrigin, credentials: true }));
app.use(express.json());

// Health check
app.get('/api/health', (req, res) => res.json({ status: 'ok', brand: 'AMINUP' }));

// REST API
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/seller', sellerRoutes);

// 404 API
app.use('/api', (req, res) => res.status(404).json({ error: 'Endpoint non trovato' }));

// Error handler
app.use((err, req, res, _next) => {
  console.error('[error]', err);
  res.status(500).json({ error: 'Errore interno del server' });
});

// Avvio (non in ambiente test)
if (process.env.NODE_ENV !== 'test') {
  app.listen(config.port, () => {
    console.log(`\n⚔️  AMINUP server in ascolto su http://localhost:${config.port}`);
    console.log(`   CORS abilitato per ${config.clientOrigin}`);
    console.log(`   Email mode: ${config.email.mode}\n`);
  });
}

export default app;
