// Piccolo wrapper fetch verso l'API REST. Aggiunge il token JWT se presente.
const BASE = '/api';

function getToken() {
  return localStorage.getItem('aminta_token');
}

async function request(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth && getToken()) headers.Authorization = `Bearer ${getToken()}`;

  const res = await fetch(BASE + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Errore ${res.status}`);
  }
  return data;
}

export const api = {
  // auth
  register: (payload) => request('/auth/register', { method: 'POST', body: payload, auth: false }),
  login: (payload) => request('/auth/login', { method: 'POST', body: payload, auth: false }),
  me: () => request('/auth/me'),
  // products
  products: (category) => request(`/products${category ? `?category=${category}` : ''}`, { auth: false }),
  // cart
  cart: () => request('/cart'),
  addToCart: (productId, qty = 1) => request('/cart/items', { method: 'POST', body: { productId, qty } }),
  updateCartItem: (id, qty) => request(`/cart/items/${id}`, { method: 'PATCH', body: { qty } }),
  removeCartItem: (id) => request(`/cart/items/${id}`, { method: 'DELETE' }),
  // coupon
  validateCoupon: (code, subtotal) => request('/coupons/validate', { method: 'POST', body: { code, subtotal } }),
  // payment
  checkout: (payload) => request('/payment/checkout', { method: 'POST', body: payload }),
  // orders
  orders: () => request('/orders'),
  // guida "come si esegue" (solo prodotti acquistati)
  guide: (productId) => request(`/products/${productId}/guide`),
  // area venditore
  sellerOrders: () => request('/seller/orders'),
  sellerStats: () => request('/seller/stats'),
  sellerSetStatus: (orderId, status) =>
    request(`/seller/orders/${orderId}/status`, { method: 'PATCH', body: { status } }),
  sellerBootstrap: () => request('/seller/bootstrap', { method: 'POST' }),
};
