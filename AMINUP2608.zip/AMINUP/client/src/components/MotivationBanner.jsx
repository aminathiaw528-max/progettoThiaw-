import { useEffect, useState } from 'react';

/** 50 frasi motivazionali su allenamento e determinazione (tema Baki / sport). */
export const QUOTES = [
  'The strongest survive. — Diventa il più forte.',
  'Un uomo che non si allena marcisce.',
  'Non mollare adesso: il dolore è temporaneo, la resa è per sempre.',
  'La forza non si eredita, si conquista.',
  'Ogni ripetizione ti avvicina al mostro che vuoi diventare.',
  'Chi smette di combattere ha già perso.',
  'Il tuo unico avversario sei tu di ieri.',
  'Il corpo raggiunge ciò che la mente crede.',
  'Non contare i giorni: fai in modo che i giorni contino.',
  'La disciplina batte la motivazione, sempre.',
  'Nessuno è mai diventato forte restando comodo.',
  'Un altro set. Poi un altro ancora.',
  'La fatica di oggi è la forza di domani.',
  'Allenati come se qualcuno stesse allenandosi per batterti.',
  'Il ferro non mente mai.',
  'Cadi sette volte, rialzati otto.',
  'Non desiderare che sia più facile: diventa più forte.',
  'Il limite esiste solo finché non lo superi.',
  'La costanza vince il talento che non si allena.',
  'Sudore oggi, gloria domani.',
  'Non aspettare il momento giusto: crealo.',
  'Il muscolo cresce dove finisce la comodità.',
  'Combatti fino all\'ultima ripetizione.',
  'Il campione si costruisce quando nessuno guarda.',
  'Scuse o risultati: scegli uno dei due.',
  'Ogni goccia di sudore è un mattone della tua fortezza.',
  'Nessuna scorciatoia porta a una vetta che valga.',
  'Il tuo corpo può quasi tutto: è la mente che devi convincere.',
  'La vera battaglia inizia quando vorresti fermarti.',
  'Mangia, allenati, riposa, ripeti.',
  'Chi domina il proprio corpo domina il proprio destino.',
  'La debolezza si allena via, un giorno alla volta.',
  'Non esistono geni: esistono ossessioni.',
  'Alzati. L\'arena non aspetta.',
  'Il dolore che scegli è meglio del rimpianto che subisci.',
  'Un guerriero non si lamenta della salita: la scala.',
  'Ripetizione dopo ripetizione, diventi inarrestabile.',
  'Il progresso è lento solo per chi lo guarda da fermo.',
  'Trasforma la rabbia in carburante.',
  'Il riposo fa parte dell\'allenamento, la resa no.',
  'Nessun avversario è più duro della tua pigrizia.',
  'Se non ti sfida, non ti cambia.',
  'La forza è una scelta che rifai ogni giorno.',
  'Meglio un allenamento imperfetto che nessun allenamento.',
  'Il tuo potenziale non ha ancora visto il tuo impegno.',
  'I risultati amano chi non salta le giornate storte.',
  'Il tuo corpo è l\'unica armatura che avrai per sempre.',
  'Vinci la mattina, vinci la giornata.',
  'Non allenarti per apparire forte: allenati per esserlo.',
  'Continua. Anche piano, ma continua.',
];

const INTERVAL = 5000; // rotazione ogni 5 secondi
const FADE = 450;      // durata della dissolvenza

export default function MotivationBanner() {
  const [index, setIndex] = useState(() => Math.floor(Math.random() * QUOTES.length));
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const tick = setInterval(() => {
      setVisible(false); // fade-out
      const swap = setTimeout(() => {
        setIndex((i) => (i + 1) % QUOTES.length);
        setVisible(true); // fade-in con la nuova frase
      }, FADE);
      return () => clearTimeout(swap);
    }, INTERVAL);
    return () => clearInterval(tick);
  }, []);

  return (
    <div className="motiv" role="status" aria-live="polite">
      <span className={`motiv-text ${visible ? 'is-in' : 'is-out'}`}>
        🔥 {QUOTES[index]}
      </span>
    </div>
  );
}
