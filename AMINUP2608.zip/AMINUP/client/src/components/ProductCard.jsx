import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useCart } from '../context/CartContext.jsx';
import ProductArt from './ProductArt.jsx';

export default function ProductCard({ product, index = 0 }) {
  const { user } = useAuth();
  const { add } = useCart();
  const navigate = useNavigate();
  const [added, setAdded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [openDetails, setOpenDetails] = useState(false);

  async function handleAdd() {
    if (!user) return navigate('/login');
    setBusy(true);
    try {
      await add(product._id, 1);
      setAdded(true);
      setTimeout(() => setAdded(false), 1400);
    } finally {
      setBusy(false);
    }
  }

  return (
    <article className="card reveal" style={{ animationDelay: `${Math.min(index, 11) * 60}ms` }}>
      <div className="card-media">
        <ProductArt art={product.art} category={product.category} className="card-art" />
        <span className="card-badge">{product.category}</span>
        {product.level && <span className="card-level">{product.level}</span>}
      </div>

      <div className="body">
        <h3 title={product.name}>{product.name}</h3>

        <p className={`desc ${openDetails ? 'expanded' : ''}`}>{product.description}</p>

        {openDetails && (
          <ul className="card-meta">
            {product.duration && <li><b>Durata:</b> {product.duration}</li>}
            {product.level && <li><b>Livello:</b> {product.level}</li>}
            {product.exercises?.length > 0 && (
              <li><b>Esercizi inclusi:</b> {product.exercises.length}</li>
            )}
            {product.usage && <li><b>Uso:</b> {product.usage}</li>}
            {product.tags?.length > 0 && (
              <li className="card-tags">{product.tags.map((t) => <span key={t}>#{t}</span>)}</li>
            )}
          </ul>
        )}

        <button className="link-btn" onClick={() => setOpenDetails((v) => !v)}>
          {openDetails ? '− Nascondi dettagli' : '+ Dettagli'}
        </button>

        <div className="card-foot">
          <span className="price">€ {product.price.toFixed(2)}</span>
          <button className={`btn buy ${added ? 'ok' : ''}`} onClick={handleAdd} disabled={busy}>
            {added ? '✓ Aggiunto' : busy ? '…' : 'Acquista'}
          </button>
        </div>
      </div>
    </article>
  );
}
