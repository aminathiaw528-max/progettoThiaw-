import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useCart } from '../context/CartContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { count } = useCart();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const close = () => setOpen(false);

  return (
    <nav className="nav">
      <div className="container nav-inner">
        <NavLink to="/" className="brand" onClick={close}>
          AMIN<span>UP</span>
        </NavLink>

        <button className="nav-toggle" onClick={() => setOpen((o) => !o)} aria-label="Menu">
          {open ? '✕' : '☰'}
        </button>

        <div className={`nav-links ${open ? 'open' : ''}`}>
          <NavLink to="/shop" className="link" onClick={close}>Shop</NavLink>
          {user && <NavLink to="/orders" className="link" onClick={close}>Ordini</NavLink>}
          {user?.role === 'seller' && (
            <NavLink to="/seller" className="link" onClick={close}>Area venditore</NavLink>
          )}
          <div className="spacer" />
          {user ? (
            <>
              <span className="link user-hi">Ciao, {user.name}</span>
              <NavLink to="/cart" className="cart-pill" onClick={close}>🛒 {count}</NavLink>
              <button className="btn ghost" onClick={() => { close(); logout(); navigate('/'); }}>
                Logout
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login" className="link" onClick={close}>Login</NavLink>
              <NavLink to="/register" className="btn" onClick={close}>Registrati</NavLink>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
