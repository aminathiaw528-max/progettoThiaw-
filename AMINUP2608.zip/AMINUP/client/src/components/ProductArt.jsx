/**
 * Illustrazioni prodotto in SVG (vettoriali, quindi nitide a qualsiasi risoluzione).
 * Stile coerente col poster Baki: cemento scuro, halftone rosa, striscia diagonale,
 * kanji di sfondo e barcode, con l'attrezzo/prodotto disegnato in primo piano.
 */

const KANJI = {
  schede: '力',        // forza
  proteine: '筋',      // muscolo
  integratori: '強',   // potenza
  attrezzatura: '闘',  // combattimento
};

const P = '#ff2e88';   // rosa primario
const PS = '#ff86bd';  // rosa tenue
const W = '#f4ecef';   // bianco caldo

/* ---------- Soggetti: ogni funzione disegna l'oggetto centrato in ~(200,165) ---------- */

const bilanciere = () => (
  <g>
    <rect x="60" y="158" width="280" height="12" rx="6" fill={W} />
    <rect x="78" y="140" width="26" height="48" rx="5" fill={P} />
    <rect x="108" y="130" width="20" height="68" rx="5" fill={PS} />
    <rect x="272" y="140" width="26" height="48" rx="5" fill={P} />
    <rect x="248" y="130" width="20" height="68" rx="5" fill={PS} />
    <rect x="64" y="150" width="10" height="28" rx="4" fill={W} />
    <rect x="326" y="150" width="10" height="28" rx="4" fill={W} />
  </g>
);

const manubrio = () => (
  <g>
    <rect x="130" y="158" width="140" height="12" rx="6" fill={W} />
    <rect x="98" y="132" width="30" height="64" rx="7" fill={P} />
    <rect x="70" y="144" width="26" height="40" rx="6" fill={PS} />
    <rect x="272" y="132" width="30" height="64" rx="7" fill={P} />
    <rect x="304" y="144" width="26" height="40" rx="6" fill={PS} />
  </g>
);

const kettlebell = () => (
  <g>
    <path d="M170 118 a30 30 0 0 1 60 0 v14 h-16 v-14 a14 14 0 0 0-28 0 v14 h-16z" fill={PS} />
    <path d="M200 130 c46 0 66 30 66 56 0 24-30 34-66 34 s-66-10-66-34c0-26 20-56 66-56z" fill={P} />
    <ellipse cx="200" cy="182" rx="26" ry="14" fill="#0a0608" opacity="0.35" />
  </g>
);

const sbarra = () => (
  <g>
    <rect x="70" y="96" width="260" height="11" rx="5" fill={W} />
    <rect x="70" y="96" width="14" height="86" rx="5" fill={PS} />
    <rect x="316" y="96" width="14" height="86" rx="5" fill={PS} />
    {/* atleta stilizzato in trazione */}
    <circle cx="200" cy="130" r="15" fill={P} />
    <path d="M200 145 v42" stroke={P} strokeWidth="11" strokeLinecap="round" />
    <path d="M200 150 l-26-46 M200 150 l26-46" stroke={P} strokeWidth="9" strokeLinecap="round" />
    <path d="M200 187 l-20 34 M200 187 l20 34" stroke={P} strokeWidth="10" strokeLinecap="round" />
  </g>
);

const guantone = () => (
  <g>
    <path d="M136 128 h74 a44 44 0 0 1 44 44 v20 a30 30 0 0 1-30 30 h-88 a34 34 0 0 1-34-34 v-26 a34 34 0 0 1 34-34z" fill={P} />
    <path d="M132 176 h-16 a20 20 0 0 0 0 40 h20" fill={P} />
    <rect x="238" y="150" width="42" height="38" rx="12" fill={PS} />
    <path d="M110 210 h130 v16 a10 10 0 0 1-10 10 h-110 a10 10 0 0 1-10-10z" fill={PS} />
    <path d="M150 150 h60" stroke="#0a0608" strokeWidth="5" opacity="0.35" strokeLinecap="round" />
  </g>
);

const mobilita = () => (
  <g>
    <circle cx="200" cy="112" r="16" fill={P} />
    <path d="M200 128 c-4 26 10 34 10 52 c0 16-16 22-16 40" stroke={P} strokeWidth="11" fill="none" strokeLinecap="round" />
    <path d="M198 150 c-30 4-46 22-46 22" stroke={PS} strokeWidth="10" fill="none" strokeLinecap="round" />
    <path d="M206 158 c30 6 44 24 44 24" stroke={PS} strokeWidth="10" fill="none" strokeLinecap="round" />
    <path d="M120 214 c40-34 120-34 160 0" stroke={W} strokeWidth="5" fill="none" opacity="0.5" strokeDasharray="9 9" />
  </g>
);

const casa = () => (
  <g>
    <path d="M120 168 l80-58 80 58" stroke={PS} strokeWidth="11" fill="none" strokeLinejoin="round" strokeLinecap="round" />
    <rect x="142" y="168" width="116" height="62" rx="6" fill="none" stroke={W} strokeWidth="6" />
    <rect x="176" y="190" width="48" height="40" rx="4" fill={P} />
    <circle cx="200" cy="150" r="9" fill={P} />
  </g>
);

const barattolo = (tint) => (
  <g>
    <rect x="140" y="120" width="120" height="24" rx="8" fill={PS} />
    <rect x="132" y="140" width="136" height="104" rx="12" fill={tint} />
    <rect x="146" y="166" width="108" height="46" rx="6" fill="#0a0608" opacity="0.45" />
    <rect x="156" y="178" width="60" height="7" rx="3.5" fill={W} />
    <rect x="156" y="192" width="40" height="6" rx="3" fill={PS} />
  </g>
);

const busta = () => (
  <g>
    <path d="M144 120 h112 a10 10 0 0 1 10 10 v104 a10 10 0 0 1-10 10 h-112 a10 10 0 0 1-10-10 v-104 a10 10 0 0 1 10-10z" fill={P} />
    <rect x="150" y="108" width="100" height="16" rx="5" fill={PS} />
    <rect x="152" y="158" width="96" height="42" rx="6" fill="#0a0608" opacity="0.45" />
    <rect x="162" y="170" width="54" height="7" rx="3.5" fill={W} />
  </g>
);

const barretta = () => (
  <g>
    <rect x="106" y="150" width="188" height="52" rx="10" fill={P} transform="rotate(-8 200 176)" />
    <rect x="126" y="164" width="60" height="9" rx="4.5" fill={W} transform="rotate(-8 200 176)" />
    <rect x="126" y="180" width="38" height="8" rx="4" fill={PS} transform="rotate(-8 200 176)" />
    <path d="M262 140 l14 -12 M276 152 l18 -8" stroke={PS} strokeWidth="6" strokeLinecap="round" />
  </g>
);

const capsule = () => (
  <g>
    <rect x="132" y="152" width="136" height="92" rx="14" fill={P} />
    <rect x="152" y="128" width="96" height="26" rx="8" fill={PS} />
    <rect x="146" y="178" width="108" height="44" rx="6" fill="#0a0608" opacity="0.45" />
    <ellipse cx="300" cy="176" rx="17" ry="27" fill={PS} transform="rotate(28 300 176)" />
    <ellipse cx="104" cy="196" rx="14" ry="23" fill={W} opacity="0.85" transform="rotate(-20 104 196)" />
  </g>
);

const borraccia = () => (
  <g>
    <rect x="166" y="102" width="68" height="22" rx="7" fill={PS} />
    <path d="M158 124 h84 a16 16 0 0 1 16 16 v92 a14 14 0 0 1-14 14 h-88 a14 14 0 0 1-14-14 v-92 a16 16 0 0 1 16-16z" fill={P} />
    <rect x="160" y="160" width="80" height="52" rx="6" fill="#0a0608" opacity="0.4" />
    <path d="M246 150 h10 M246 168 h10 M246 186 h10" stroke={W} strokeWidth="4" strokeLinecap="round" opacity="0.8" />
  </g>
);

const bustina = () => (
  <g>
    <path d="M138 130 h124 v96 l-12 12 h-100 l-12-12z" fill={P} />
    <path d="M138 130 l10-12 h104 l10 12z" fill={PS} />
    <rect x="156" y="164" width="88" height="34" rx="5" fill="#0a0608" opacity="0.45" />
    <circle cx="200" cy="181" r="9" fill={W} opacity="0.9" />
  </g>
);

const corda = () => (
  <g>
    <path d="M118 130 c-56 40-40 110 82 110 s138-70 82-110" stroke={P} strokeWidth="10" fill="none" strokeLinecap="round" />
    <rect x="96" y="106" width="26" height="60" rx="12" fill={PS} transform="rotate(-16 109 136)" />
    <rect x="278" y="106" width="26" height="60" rx="12" fill={PS} transform="rotate(16 291 136)" />
  </g>
);

const elastici = () => (
  <g>
    <path d="M104 200 c40-70 152-70 192 0" stroke={P} strokeWidth="12" fill="none" strokeLinecap="round" />
    <path d="M118 216 c36-58 128-58 164 0" stroke={PS} strokeWidth="10" fill="none" strokeLinecap="round" />
    <path d="M132 230 c30-46 106-46 136 0" stroke={W} strokeWidth="8" fill="none" strokeLinecap="round" opacity="0.85" />
    <rect x="88" y="192" width="22" height="46" rx="10" fill={W} />
    <rect x="290" y="192" width="22" height="46" rx="10" fill={W} />
  </g>
);

const anelli = () => (
  <g>
    <path d="M160 92 v46 M240 92 v46" stroke={W} strokeWidth="7" strokeLinecap="round" />
    <circle cx="160" cy="180" r="40" fill="none" stroke={P} strokeWidth="15" />
    <circle cx="240" cy="180" r="40" fill="none" stroke={PS} strokeWidth="15" />
  </g>
);

const shaker = () => (
  <g>
    <rect x="160" y="98" width="80" height="20" rx="7" fill={PS} />
    <path d="M154 118 h92 v104 a16 16 0 0 1-16 16 h-60 a16 16 0 0 1-16-16z" fill={P} />
    <path d="M244 140 c18 4 18 26 0 30" stroke={PS} strokeWidth="8" fill="none" strokeLinecap="round" />
    <path d="M166 150 h20 M166 168 h20 M166 186 h20" stroke={W} strokeWidth="4" strokeLinecap="round" opacity="0.85" />
  </g>
);

const ART = {
  barbell: bilanciere,
  dumbbell: manubrio,
  kettlebell,
  calisthenics: sbarra,
  boxing: guantone,
  mobility: mobilita,
  home: casa,
  'tub-choco': () => barattolo('#8a4a2f'),
  'tub-vanilla': () => barattolo('#c9a86a'),
  'tub-night': () => barattolo('#3b2b57'),
  pouch: busta,
  bar: barretta,
  creatine: () => barattolo('#4a3550'),
  zma: capsule,
  bcaa: capsule,
  omega: capsule,
  preworkout: borraccia,
  electrolytes: bustina,
  rope: corda,
  bands: elastici,
  rings: anelli,
  gloves: guantone,
  shaker,
};

export default function ProductArt({ art, category = 'schede', className = '' }) {
  const draw = ART[art] || bilanciere;
  const uid = `pa-${art || 'x'}`;

  return (
    <svg className={className} viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice"
      role="img" aria-label={`Illustrazione ${art || category}`}>
      <defs>
        <linearGradient id={`${uid}-bg`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1d1117" />
          <stop offset="1" stopColor="#080507" />
        </linearGradient>
        <pattern id={`${uid}-dots`} width="14" height="14" patternUnits="userSpaceOnUse">
          <circle cx="3" cy="3" r="1.6" fill={P} opacity="0.2" />
        </pattern>
        <filter id={`${uid}-noise`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" />
          <feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.05 0" />
        </filter>
      </defs>

      {/* sfondo editoriale */}
      <rect width="400" height="300" fill={`url(#${uid}-bg)`} />
      <rect width="400" height="300" filter={`url(#${uid}-noise)`} />
      <rect width="150" height="300" fill={`url(#${uid}-dots)`} />
      <polygon points="0,300 210,300 76,120 0,178" fill={P} opacity="0.10" />
      <rect x="-20" y="236" width="330" height="9" fill={P} opacity="0.85" transform="rotate(-12 0 236)" />
      <text x="322" y="238" fontFamily="'Arial Black', Arial, sans-serif" fontSize="176"
        fill={P} opacity="0.10" textAnchor="middle">{KANJI[category] || '力'}</text>

      {/* soggetto */}
      <g>{draw()}</g>

      {/* dettagli editoriali */}
      <g fill={W} opacity="0.8">
        {[0, 4, 7, 12, 15, 19, 25, 28, 32, 37].map((x, i) => (
          <rect key={i} x={22 + x} y="266" width={i % 3 === 0 ? 3 : 1.5} height="16" />
        ))}
      </g>
      <text x="378" y="286" fontFamily="Arial, sans-serif" fontSize="10" letterSpacing="2"
        fill={P} textAnchor="end">///</text>
    </svg>
  );
}
