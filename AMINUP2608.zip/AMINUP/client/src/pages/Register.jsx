import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [preview, setPreview] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError(''); setBusy(true);
    try {
      const d = await register(name, email, password);
      // In modalità Ethereal riceviamo un link di anteprima della mail di benvenuto
      if (d.emailPreview) {
        setPreview(d.emailPreview);
        setTimeout(() => navigate('/shop'), 2500);
      } else {
        navigate('/shop');
      }
    } catch (err) {
      setError(err.message);
    } finally { setBusy(false); }
  }

  return (
    <div className="auth-wrap">
      <div className="panel">
        <h2 style={{ marginTop: 0 }}>Unisciti all'arena</h2>
        <p className="muted">Crea il tuo account. Usa una email reale: la verifichiamo.</p>
        {error && <div className="error" style={{ marginBottom: 14 }}>{error}</div>}
        {preview && (
          <div className="success" style={{ marginBottom: 14 }}>
            Account creato! Mail di benvenuto inviata.{' '}
            <a href={preview} target="_blank" rel="noreferrer" style={{ color: 'var(--gold)' }}>Apri anteprima email</a>
          </div>
        )}
        <form onSubmit={submit}>
          <div className="field">
            <label>Nome guerriero</label>
            <input value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="field">
            <label>Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="field">
            <label>Password (min 6 caratteri)</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <button className="btn block" disabled={busy}>{busy ? '…' : 'Crea account'}</button>
        </form>
        <p className="muted" style={{ marginTop: 16 }}>
          Hai già un account? <Link to="/login" style={{ color: 'var(--gold)' }}>Accedi</Link>
        </p>
      </div>
    </div>
  );
}
