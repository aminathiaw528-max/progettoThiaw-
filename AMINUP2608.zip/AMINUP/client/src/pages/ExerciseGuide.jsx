import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api.js';
import ProductArt from '../components/ProductArt.jsx';

export default function ExerciseGuide() {
  const { productId } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.guide(productId)
      .then(setData)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [productId]);

  if (loading) return <div className="container" style={{ padding: 40 }}>Caricamento guida…</div>;

  if (error) {
    return (
      <div className="container" style={{ padding: 40, maxWidth: 640 }}>
        <div className="panel">
          <h2 style={{ marginTop: 0 }}>Guida non disponibile</h2>
          <div className="error">{error}</div>
          <p className="muted" style={{ marginTop: 14 }}>
            Le guide di esecuzione sono riservate a chi ha acquistato il prodotto.
          </p>
          <Link to="/shop" className="btn">Vai al catalogo</Link>
        </div>
      </div>
    );
  }

  const { product, exercises, usage } = data;

  return (
    <div className="container guide-wrap">
      <div className="guide-head panel">
        <div className="guide-art">
          <ProductArt art={product.art} category={product.category} className="card-art" />
        </div>
        <div>
          <span className="tag">{product.category} · guida inclusa</span>
          <h2 style={{ margin: '6px 0' }}>{product.name}</h2>
          <p className="muted">{product.description}</p>
          <div className="guide-facts">
            {product.level && <span className="fact">Livello: <b>{product.level}</b></span>}
            {product.duration && <span className="fact">Durata: <b>{product.duration}</b></span>}
            {exercises.length > 0 && <span className="fact">Esercizi: <b>{exercises.length}</b></span>}
          </div>
        </div>
      </div>

      {usage && (
        <div className="panel" style={{ marginTop: 18 }}>
          <h3 style={{ marginTop: 0 }}>Come si assume</h3>
          <p>{usage}</p>
        </div>
      )}

      {exercises.length > 0 && (
        <>
          <h3 className="section-title" style={{ fontSize: 24 }}>Come si eseguono gli esercizi</h3>
          <div className="exercise-list">
            {exercises.map((ex, i) => (
              <div className="panel exercise reveal" key={ex.name} style={{ animationDelay: `${i * 70}ms` }}>
                <div className="exercise-top">
                  <span className="exercise-num">{String(i + 1).padStart(2, '0')}</span>
                  <div>
                    <h4>{ex.name}</h4>
                    {ex.sets && <span className="tag">{ex.sets}</span>}
                  </div>
                </div>
                <p className="exercise-how">{ex.how}</p>
                {ex.video && (
                  <a className="btn ghost video-link" href={ex.video} target="_blank" rel="noreferrer">
                    ▶ Guarda come si esegue
                  </a>
                )}
              </div>
            ))}
          </div>
        </>
      )}

      <div style={{ margin: '28px 0' }}>
        <Link to="/orders" className="btn ghost">← Torna ai miei ordini</Link>
      </div>
    </div>
  );
}
