import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext.jsx';

export default function Cart() {
  const { items, subtotal, update, remove } = useCart();
  const navigate = useNavigate();

  if (items.length === 0) {
    return (
      <div className="container" style={{ padding: '40px 20px' }}>
        <h2 className="section-title">Il tuo carrello è vuoto</h2>
        <p className="muted">Non mollare adesso — l'arena ti aspetta.</p>
        <Link to="/shop" className="btn">Vai al catalogo</Link>
      </div>
    );
  }

  return (
    <div className="container" style={{ padding: '30px 20px' }}>
      <h2 className="section-title">Carrello</h2>
      <div className="motiv" style={{ borderRadius: 10, margin: '10px 0 20px' }}>
        🔥 Sei a un passo dalla tua trasformazione. Non fermarti ora!
      </div>
      <div className="two-col">
        <div className="panel">
          {items.map((i) => (
            <div className="row" key={i.id}>
              <div style={{ width: 44, height: 44, borderRadius: 8, background: 'linear-gradient(135deg,#3a1226,#12080e)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 900 }}>
                {i.name.charAt(0)}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700 }}>{i.name}</div>
                <div className="muted" style={{ fontSize: 13 }}>€ {i.price.toFixed(2)}</div>
              </div>
              <div className="qty">
                <button onClick={() => update(i.id, Math.max(1, i.qty - 1))}>−</button>
                <span>{i.qty}</span>
                <button onClick={() => update(i.id, i.qty + 1)}>+</button>
              </div>
              <div style={{ width: 80, textAlign: 'right', fontWeight: 800 }}>€ {(i.price * i.qty).toFixed(2)}</div>
              <button className="btn ghost" onClick={() => remove(i.id)}>✕</button>
            </div>
          ))}
        </div>

        <div className="panel">
          <h3 style={{ marginTop: 0 }}>Riepilogo</h3>
          <div className="summary-line"><span>Subtotale</span><span>€ {subtotal.toFixed(2)}</span></div>
          <div className="summary-total"><span>Totale</span><span>€ {subtotal.toFixed(2)}</span></div>
          {/* I due CTA sono in una colonna flex con gap: niente più sovrapposizione */}
          <div className="cta-stack">
            <button className="btn gold block" onClick={() => navigate('/checkout')}>
              Vai al pagamento
            </button>
            <Link to="/shop" className="btn ghost block">Continua lo shopping</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
