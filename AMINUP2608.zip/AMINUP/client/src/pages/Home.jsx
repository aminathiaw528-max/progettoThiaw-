import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { api } from '../api.js';
import ProductCard from '../components/ProductCard.jsx';

export default function Home() {
  const [featured, setFeatured] = useState([]);
  useEffect(() => {
    api.products().then((d) => {
      // una selezione mista: un prodotto per categoria + i primi rimanenti
      const cats = [...new Set(d.products.map((p) => p.category))];
      const pick = cats.map((c) => d.products.find((p) => p.category === c)).filter(Boolean);
      const rest = d.products.filter((p) => !pick.includes(p));
      setFeatured([...pick, ...rest].slice(0, 8));
    }).catch(() => {});
  }, []);

  return (
    <>
      <section className="hero">
        <h1>DIVENTA IL <em>PIÙ FORTE</em></h1>
        <p>Schede di allenamento, proteine e integratori per chi non molla mai.
          Entra nell'arena e costruisci il corpo di un mostro.</p>
        <div className="hero-cta">
          <Link to="/shop" className="btn gold">Esplora il catalogo</Link>
          <Link to="/register" className="btn ghost">Unisciti all'arena</Link>
        </div>
      </section>

      <div className="container">
        <h2 className="section-title">In evidenza</h2>
        <p className="muted">I preferiti dei guerrieri.</p>
        <div className="grid" style={{ marginTop: 20 }}>
          {featured.map((p, i) => <ProductCard key={p._id} product={p} index={i} />)}
        </div>

        <div className="panel" style={{ margin: '50px 0', textAlign: 'center' }}>
          <h2 style={{ color: 'var(--gold)' }}>"Un uomo che non si allena marcisce."</h2>
          <p className="muted">Il tuo unico avversario sei tu di ieri. Non mollare.</p>
          <Link to="/shop" className="btn">Inizia ora</Link>
        </div>
      </div>
    </>
  );
}
