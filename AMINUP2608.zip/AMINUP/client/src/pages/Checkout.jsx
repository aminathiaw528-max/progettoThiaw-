import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useCart } from '../context/CartContext.jsx';

export default function Checkout() {
  const { items, subtotal, setItems } = useCart();
  const navigate = useNavigate();

  const [method, setMethod] = useState('card');
  const [card, setCard] = useState({ number: '4242 4242 4242 4242', exp: '12/30', cvc: '123' });
  const [couponCode, setCouponCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [couponMsg, setCouponMsg] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);

  const total = Math.max(0, Number((subtotal - discount).toFixed(2)));

  async function applyCoupon() {
    setCouponMsg(''); setError('');
    try {
      const d = await api.validateCoupon(couponCode, subtotal);
      setDiscount(d.discount);
      setCouponMsg(d.discount > 0 ? `Coupon applicato: −€ ${d.discount.toFixed(2)}` : 'Nessuno sconto');
    } catch (err) {
      setDiscount(0);
      setCouponMsg('');
      setError(err.message);
    }
  }

  async function pay() {
    setError(''); setBusy(true);
    try {
      const payload = { method, couponCode: couponCode || undefined };
      if (method === 'card') payload.card = card;
      const d = await api.checkout(payload);
      setItems([]);
      setDone(d);
    } catch (err) {
      setError(err.message);
    } finally { setBusy(false); }
  }

  if (done) {
    return (
      <div className="container" style={{ padding: '40px 20px', maxWidth: 640 }}>
        <div className="panel center">
          <h2 style={{ color: 'var(--gold)' }}>🔥 Pagamento riuscito!</h2>
          <p>Ordine <b>#{done.order.id}</b> — Totale <b>€ {done.order.total.toFixed(2)}</b></p>
          <p className="muted">Transazione: {done.transactionId}</p>
          {done.emailPreview && (
            <p><a className="btn ghost" href={done.emailPreview} target="_blank" rel="noreferrer">Apri ricevuta email</a></p>
          )}
          <p className="muted">Ora vai ad allenarti. Non mollare.</p>
          <button className="btn" onClick={() => navigate('/orders')}>Vedi i miei ordini</button>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="container" style={{ padding: 40 }}>
        <h2>Carrello vuoto</h2>
        <button className="btn" onClick={() => navigate('/shop')}>Torna al catalogo</button>
      </div>
    );
  }

  return (
    <div className="container" style={{ padding: '30px 20px' }}>
      <h2 className="section-title">Checkout sicuro</h2>
      <p className="muted">🔒 Pagamento di test cifrato AES-256-GCM. Nessun dato reale viene addebitato.</p>
      {error && <div className="error" style={{ margin: '12px 0' }}>{error}</div>}

      <div className="two-col">
        <div className="panel">
          <h3 style={{ marginTop: 0 }}>Metodo di pagamento</h3>
          <div className="pay-methods">
            {['card', 'applepay', 'coupon'].map((m) => (
              <div key={m} className={`chip ${method === m ? 'active' : ''}`} onClick={() => setMethod(m)}>
                {m === 'card' ? '💳 Carta' : m === 'applepay' ? ' Apple Pay' : '🎟️ Solo coupon'}
              </div>
            ))}
          </div>

          {method === 'card' && (
            <>
              <div className="field">
                <label>Numero carta (test: 4242 4242 4242 4242)</label>
                <input value={card.number} onChange={(e) => setCard({ ...card, number: e.target.value })} />
              </div>
              <div className="field-row">
                <div className="field">
                  <label>Scadenza</label>
                  <input value={card.exp} onChange={(e) => setCard({ ...card, exp: e.target.value })} placeholder="MM/AA" inputMode="numeric" />
                </div>
                <div className="field">
                  <label>CVC</label>
                  <input value={card.cvc} onChange={(e) => setCard({ ...card, cvc: e.target.value })} inputMode="numeric" />
                </div>
              </div>
            </>
          )}

          {method === 'applepay' && (
            <div className="panel" style={{ background: '#000', textAlign: 'center' }}>
              <p style={{ fontSize: 22, fontWeight: 800 }}> Pay</p>
              <p className="muted">Apple Pay simulato: conferma per pagare in un tap.</p>
            </div>
          )}

          {method === 'coupon' && (
            <p className="muted">Paga interamente con coupon (se copre il totale). Inserisci il codice nel riepilogo.</p>
          )}
        </div>

        <div className="panel">
          <h3 style={{ marginTop: 0 }}>Riepilogo ordine</h3>
          {items.map((i) => (
            <div className="summary-line" key={i.id}>
              <span>{i.name} × {i.qty}</span><span>€ {(i.price * i.qty).toFixed(2)}</span>
            </div>
          ))}

          <div className="field" style={{ marginTop: 14 }}>
            <label>Coupon (prova: BAKI20)</label>
            <div className="coupon-row">
              <input value={couponCode} onChange={(e) => setCouponCode(e.target.value)} placeholder="Codice sconto" />
              <button className="btn ghost" type="button" onClick={applyCoupon}>Applica</button>
            </div>
          </div>
          {couponMsg && <div className="success" style={{ marginBottom: 10 }}>{couponMsg}</div>}

          <div className="summary-line"><span>Subtotale</span><span>€ {subtotal.toFixed(2)}</span></div>
          <div className="summary-line"><span>Sconto</span><span>− € {discount.toFixed(2)}</span></div>
          <div className="summary-total"><span>Totale</span><span>€ {total.toFixed(2)}</span></div>

          <button className="btn gold block" style={{ marginTop: 18 }} disabled={busy} onClick={pay}>
            {busy ? 'Elaborazione…' : `Paga € ${total.toFixed(2)}`}
          </button>
        </div>
      </div>
    </div>
  );
}
