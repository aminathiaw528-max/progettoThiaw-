import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError(''); setBusy(true);
    try {
      await login(email, password);
      navigate('/shop');
    } catch (err) {
      setError(err.message);
    } finally { setBusy(false); }
  }

  return (
    <div className="auth-wrap">
      <div className="panel">
        <h2 style={{ marginTop: 0 }}>Torna nell'arena</h2>
        <p className="muted">Accedi per continuare la tua ascesa.</p>
        {error && <div className="error" style={{ marginBottom: 14 }}>{error}</div>}
        <form onSubmit={submit}>
          <div className="field">
            <label>Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="field">
            <label>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <button className="btn block" disabled={busy}>{busy ? '…' : 'Accedi'}</button>
        </form>
        <p className="muted" style={{ marginTop: 16 }}>
          Non hai un account? <Link to="/register" style={{ color: 'var(--gold)' }}>Registrati</Link>
        </p>
      </div>
    </div>
  );
}
