import { useEffect, useState } from 'react';
import { api } from '../api.js';
import ProductCard from '../components/ProductCard.jsx';

const CATS = [
  { key: '', label: 'Tutti' },
  { key: 'schede', label: '力 Schede allenamento' },
  { key: 'proteine', label: '筋 Proteine' },
  { key: 'integratori', label: '強 Integratori' },
  { key: 'attrezzatura', label: '闘 Attrezzatura' },
];

export default function Shop() {
  const [cat, setCat] = useState('');
  const [query, setQuery] = useState('');
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.products(cat)
      .then((d) => setProducts(d.products))
      .finally(() => setLoading(false));
  }, [cat]);

  const filtered = products.filter((p) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return (p.name + ' ' + p.description + ' ' + (p.tags || []).join(' ')).toLowerCase().includes(q);
  });

  return (
    <div className="container shop-wrap">
      <header className="shop-head">
        <h2 className="section-title">Il Catalogo dell'Arena</h2>
        <p className="muted">Schede, nutrizione e attrezzatura per chi non molla mai.</p>
      </header>

      <div className="shop-controls">
        <div className="filters">
          {CATS.map((c) => (
            <button
              key={c.key}
              className={`chip ${cat === c.key ? 'active' : ''}`}
              onClick={() => setCat(c.key)}
            >
              {c.label}
            </button>
          ))}
        </div>
        <input
          className="search"
          type="search"
          placeholder="Cerca un prodotto…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="grid">
          {Array.from({ length: 8 }).map((_, i) => <div key={i} className="card skeleton" />)}
        </div>
      ) : (
        <>
          <p className="muted result-count">{filtered.length} prodotti</p>
          <div className="grid">
            {filtered.map((p, i) => <ProductCard key={p._id} product={p} index={i} />)}
          </div>
          {filtered.length === 0 && (
            <p className="muted center" style={{ padding: 40 }}>
              Nessun prodotto trovato. Prova con un'altra ricerca.
            </p>
          )}
        </>
      )}
    </div>
  );
}
