import { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';

const FLOW = [
  { key: 'paid', label: 'Ordini ricevuti', icon: '📥', next: 'processing', nextLabel: 'Prepara' },
  { key: 'processing', label: 'Da consegnare', icon: '📦', next: 'shipped', nextLabel: 'Spedisci' },
  { key: 'shipped', label: 'Spediti', icon: '🚚', next: 'completed', nextLabel: 'Completa' },
  { key: 'completed', label: 'Passati / Completati', icon: '✅', next: null },
];

const euro = (n) => '€ ' + Number(n || 0).toFixed(2);

function StatCard({ label, value, sub, accent }) {
  return (
    <div className={`stat-card ${accent ? 'accent' : ''}`}>
      <span className="stat-label">{label}</span>
      <span className="stat-value">{value}</span>
      {sub && <span className="stat-sub">{sub}</span>}
    </div>
  );
}

export default function SellerDashboard() {
  const [stats, setStats] = useState(null);
  const [groups, setGroups] = useState(null);
  const [tab, setTab] = useState('paid');
  const [error, setError] = useState('');
  const [needsBootstrap, setNeedsBootstrap] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [s, o] = await Promise.all([api.sellerStats(), api.sellerOrders()]);
      setStats(s);
      setGroups(o.groups);
      setNeedsBootstrap(false);
    } catch (e) {
      setError(e.message);
      if (e.message.toLowerCase().includes('venditor')) setNeedsBootstrap(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function advance(orderId, status) {
    try {
      await api.sellerSetStatus(orderId, status);
      await load();
    } catch (e) { setError(e.message); }
  }

  async function claim() {
    try {
      await api.sellerBootstrap();
      await load();
    } catch (e) { setError(e.message); }
  }

  if (loading) return <div className="container" style={{ padding: 40 }}>Caricamento dashboard…</div>;

  if (needsBootstrap) {
    return (
      <div className="container" style={{ padding: 40, maxWidth: 560 }}>
        <div className="panel center">
          <h2 style={{ marginTop: 0 }}>Area venditore</h2>
          <div className="error" style={{ marginBottom: 14 }}>{error}</div>
          <p className="muted">
            Questo shop non ha ancora un venditore. Puoi rivendicare tu la gestione
            (demo: funziona solo se nessun altro l'ha già fatto).
          </p>
          <button className="btn gold" onClick={claim}>Diventa venditore di AMINUP</button>
        </div>
      </div>
    );
  }

  const active = FLOW.find((f) => f.key === tab);
  const list = groups?.[tab]?.orders || [];

  return (
    <div className="container seller-wrap">
      <header className="shop-head">
        <h2 className="section-title">Dashboard venditore</h2>
        <p className="muted">Andamento vendite e gestione degli ordini di AMINUP.</p>
      </header>

      {error && <div className="error" style={{ marginBottom: 16 }}>{error}</div>}

      {/* --- Metriche finanziarie --- */}
      <div className="stat-grid">
        <StatCard label="Guadagno totale" value={euro(stats.revenue)} sub={`${stats.orders} ordini`} accent />
        <StatCard label="Ultimi 7 giorni" value={euro(stats.last7.revenue)} sub={`${stats.last7.orders} ordini`} />
        <StatCard label="Valore medio ordine" value={euro(stats.avgOrder)} />
        <StatCard label="Articoli venduti" value={stats.itemsSold} />
        <StatCard label="Clienti" value={stats.customers} />
        <StatCard label="Sconti erogati" value={euro(stats.discounts)} sub="coupon applicati" />
      </div>

      <div className="seller-cols">
        {/* --- Prodotti più venduti --- */}
        <div className="panel">
          <h3 style={{ marginTop: 0 }}>Prodotti più venduti</h3>
          {stats.topProducts.length === 0 ? (
            <p className="muted">Ancora nessuna vendita.</p>
          ) : (
            <table className="mini-table">
              <thead>
                <tr><th>Prodotto</th><th>Q.tà</th><th>Ricavo</th></tr>
              </thead>
              <tbody>
                {stats.topProducts.map((p) => (
                  <tr key={p.product_id}>
                    <td>{p.name}</td>
                    <td>{p.qty}</td>
                    <td>{euro(p.revenue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* --- Ricavo per giorno (mini grafico a barre) --- */}
        <div className="panel">
          <h3 style={{ marginTop: 0 }}>Ricavo ultimi 14 giorni</h3>
          {stats.byDay.length === 0 ? (
            <p className="muted">Nessun dato disponibile.</p>
          ) : (
            <div className="bar-chart">
              {stats.byDay.map((d) => {
                const max = Math.max(...stats.byDay.map((x) => x.revenue)) || 1;
                return (
                  <div className="bar-col" key={d.day} title={`${d.day}: ${euro(d.revenue)}`}>
                    <div className="bar" style={{ height: `${Math.max(6, (d.revenue / max) * 100)}%` }} />
                    <span className="bar-label">{d.day.slice(5)}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* --- Gestione ordini --- */}
      <h3 className="section-title" style={{ fontSize: 24 }}>Gestione ordini</h3>
      <div className="filters">
        {FLOW.map((f) => (
          <button
            key={f.key}
            className={`chip ${tab === f.key ? 'active' : ''}`}
            onClick={() => setTab(f.key)}
          >
            {f.icon} {f.label} ({groups?.[f.key]?.orders.length || 0})
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <div className="panel"><p className="muted" style={{ margin: 0 }}>Nessun ordine in "{active.label}".</p></div>
      ) : (
        <div className="table-scroll">
          <table className="orders-table">
            <thead>
              <tr>
                <th>#</th><th>Cliente</th><th>Articoli</th><th>Data</th>
                <th>Pagamento</th><th>Totale</th><th>Azione</th>
              </tr>
            </thead>
            <tbody>
              {list.map((o) => (
                <tr key={o.id}>
                  <td><b>#{o.id}</b></td>
                  <td>
                    <div>{o.customer_name}</div>
                    <div className="muted small">{o.customer_email}</div>
                  </td>
                  <td>
                    {o.items.map((i) => (
                      <div key={i.id} className="small">{i.name} × {i.qty}</div>
                    ))}
                  </td>
                  <td className="small">{o.created_at}</td>
                  <td className="small">
                    {o.payment?.method}
                    {o.payment?.card_last4 ? ` ••••${o.payment.card_last4}` : ''}
                  </td>
                  <td><b className="price">{euro(o.total)}</b></td>
                  <td>
                    {active.next ? (
                      <button className="btn small-btn" onClick={() => advance(o.id, active.next)}>
                        {active.nextLabel} →
                      </button>
                    ) : (
                      <span className="tag">completato</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
