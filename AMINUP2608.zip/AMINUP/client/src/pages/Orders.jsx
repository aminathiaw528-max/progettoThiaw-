import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';

const STATUS_LABEL = {
  paid: 'Ricevuto',
  processing: 'In preparazione',
  shipped: 'Spedito',
  completed: 'Completato',
  pending: 'In attesa',
};

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.orders().then((d) => setOrders(d.orders)).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="container" style={{ padding: 40 }}>Caricamento…</div>;

  if (orders.length === 0) {
    return (
      <div className="container" style={{ padding: 40 }}>
        <h2 className="section-title">Nessun ordine</h2>
        <p className="muted">La tua leggenda non è ancora iniziata.</p>
        <Link to="/shop" className="btn">Inizia ora</Link>
      </div>
    );
  }

  return (
    <div className="container" style={{ padding: '30px 20px' }}>
      <h2 className="section-title">Storico ordini &amp; pagamenti</h2>
      <p className="muted">
        Per ogni articolo acquistato puoi aprire la guida che mostra <b>come si esegue</b>.
      </p>

      {orders.map((o, idx) => (
        <div className="panel reveal" key={o.id} style={{ marginBottom: 16, animationDelay: `${idx * 60}ms` }}>
          <div className="order-head">
            <div>
              <b>Ordine #{o.id}</b>{' '}
              <span className={`tag status-${o.status}`}>{STATUS_LABEL[o.status] || o.status}</span>
              <div className="muted small">{o.created_at}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div className="price">€ {o.total.toFixed(2)}</div>
              {o.payment && (
                <div className="muted small">
                  {o.payment.method}
                  {o.payment.card_last4 ? ` •••• ${o.payment.card_last4}` : ''}
                  {' · '}{o.payment.transaction_id}
                </div>
              )}
            </div>
          </div>

          <div className="order-items">
            {o.items.map((i) => (
              <div className="order-item" key={i.id}>
                <span className="order-item-name">{i.name} × {i.qty}</span>
                <Link className="guide-link" to={`/guida/${i.product_id}`}>
                  ▶ Come si esegue
                </Link>
                <span className="order-item-price">€ {(i.price * i.qty).toFixed(2)}</span>
              </div>
            ))}
            {o.discount > 0 && (
              <div className="summary-line">
                <span>Sconto {o.coupon_code ? `(${o.coupon_code})` : ''}</span>
                <span>− € {o.discount.toFixed(2)}</span>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
