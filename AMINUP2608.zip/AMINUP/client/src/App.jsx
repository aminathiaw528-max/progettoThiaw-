import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import MotivationBanner from './components/MotivationBanner.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Home from './pages/Home.jsx';
import Shop from './pages/Shop.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Cart from './pages/Cart.jsx';
import Checkout from './pages/Checkout.jsx';
import Orders from './pages/Orders.jsx';
import ExerciseGuide from './pages/ExerciseGuide.jsx';
import SellerDashboard from './pages/SellerDashboard.jsx';

export default function App() {
  return (
    <>
      <Navbar />
      <MotivationBanner />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/cart" element={<ProtectedRoute><Cart /></ProtectedRoute>} />
          <Route path="/checkout" element={<ProtectedRoute><Checkout /></ProtectedRoute>} />
          <Route path="/orders" element={<ProtectedRoute><Orders /></ProtectedRoute>} />
          <Route path="/guida/:productId" element={<ProtectedRoute><ExerciseGuide /></ProtectedRoute>} />
          <Route path="/seller" element={<ProtectedRoute><SellerDashboard /></ProtectedRoute>} />
          <Route path="*" element={
            <div className="container" style={{ padding: 60 }}><h2>404 — Pagina non trovata</h2></div>
          } />
        </Routes>
      </main>
      <footer className="footer">
        <div className="container">
          AMINUP © {new Date().getFullYear()} — Get stronger. Never yield. · Progetto didattico, pagamenti di test.
        </div>
      </footer>
    </>
  );
}
