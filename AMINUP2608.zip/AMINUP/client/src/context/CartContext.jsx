import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import { useAuth } from './AuthContext.jsx';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const { user } = useAuth();
  const [items, setItems] = useState([]);

  const refresh = useCallback(async () => {
    if (!user) { setItems([]); return; }
    try {
      const d = await api.cart();
      setItems(d.items);
    } catch { setItems([]); }
  }, [user]);

  useEffect(() => { refresh(); }, [refresh]);

  async function add(productId, qty = 1) {
    const d = await api.addToCart(productId, qty);
    setItems(d.items);
  }
  async function update(id, qty) {
    const d = await api.updateCartItem(id, qty);
    setItems(d.items);
  }
  async function remove(id) {
    const d = await api.removeCartItem(id);
    setItems(d.items);
  }

  const count = items.reduce((s, i) => s + i.qty, 0);
  const subtotal = Number(items.reduce((s, i) => s + i.price * i.qty, 0).toFixed(2));

  return (
    <CartContext.Provider value={{ items, count, subtotal, add, update, remove, refresh, setItems }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
