import { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('aminta_token');
    if (!token) { setLoading(false); return; }
    api.me()
      .then((d) => setUser(d.user))
      .catch(() => localStorage.removeItem('aminta_token'))
      .finally(() => setLoading(false));
  }, []);

  async function login(email, password) {
    const d = await api.login({ email, password });
    localStorage.setItem('aminta_token', d.token);
    setUser(d.user);
    return d;
  }

  async function register(name, email, password) {
    const d = await api.register({ name, email, password });
    localStorage.setItem('aminta_token', d.token);
    setUser(d.user);
    return d; // include emailPreview (link anteprima mail benvenuto)
  }

  function logout() {
    localStorage.removeItem('aminta_token');
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
