import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Il dev server React (5173) inoltra le chiamate /api al backend Node (4000)
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:4000',
    },
  },
});
