# AMINUP — Guida di avvio passo passo

Guida completa per far partire il progetto da zero su Windows.
Tempo stimato: **5 minuti** (primo avvio), **30 secondi** (avvii successivi).

---

## Prerequisito — Node.js

Serve **Node.js 22.5+** (consigliato **24 LTS**): il progetto usa il modulo SQLite
integrato `node:sqlite`, quindi **non serve compilare nulla**.

**Verifica se è già installato.** Apri PowerShell e digita:

```powershell
node --version
```

- Se risponde `v24.x.x` (o ≥ v22.5) → sei a posto, salta al Passo 1.
- Se dice *"termine non riconosciuto"* → installalo:

```powershell
winget install OpenJS.NodeJS.LTS
```

> ⚠️ **Dopo l'installazione chiudi e riapri il terminale**, altrimenti `node` e `npm`
> non vengono trovati (il PATH non è aggiornato nelle finestre già aperte).

---

## Passo 1 — Apri due terminali

Il progetto ha due processi separati che devono girare **contemporaneamente**:

| Terminale | Cosa esegue | Porta |
|-----------|-------------|-------|
| **1** | Backend — server Node.js + API REST | `4000` |
| **2** | Frontend — interfaccia React | `5173` |

---

## Passo 2 — Avvia il BACKEND (terminale 1)

### 2.1 — Entra nella cartella del server

Posizionati nella cartella del progetto (quella che contiene `server/` e `client/`) e poi:

```powershell
cd server
```

> Suggerimento: apri la cartella del progetto in Esplora risorse, scrivi `powershell`
> nella barra degli indirizzi e premi Invio: il terminale si apre già nel punto giusto.

### 2.2 — Installa le dipendenze (solo la prima volta)
```powershell
npm install
```

### 2.3 — Popola il database (solo la prima volta, o per ricaricare il catalogo)
```powershell
npm run seed
```
Output atteso:
```
[seed] 23 prodotti inseriti/aggiornati (NeDB).
[seed] 5 coupon inseriti/aggiornati (SQLite).
```

### 2.4 — Avvia il server
```powershell
npm run dev
```
Output atteso:
```
⚔️  AMINUP server in ascolto su http://localhost:4000
   CORS abilitato per http://localhost:5173
   Email mode: ethereal
```

✅ **Lascia questo terminale aperto.** Chiuderlo spegne il backend.

---

## Passo 3 — Avvia il FRONTEND (terminale 2)

### 3.1 — Entra nella cartella del client

Dalla cartella del progetto (**non** da `server/`):

```powershell
cd client
```

### 3.2 — Installa le dipendenze (solo la prima volta)
```powershell
npm install
```

### 3.3 — Avvia l'interfaccia
```powershell
npm run dev
```
Output atteso:
```
VITE v5.4.21  ready in 1850 ms
➜  Local:   http://localhost:5173/
```

---

## Passo 4 — Apri il sito

Vai su **<http://localhost:5173>** nel browser. 🎉

---

## Comandi utili

| Comando | Cartella | Cosa fa |
|---------|----------|---------|
| `npm run dev` | server | Avvia il backend con auto-reload |
| `npm start` | server | Avvia il backend senza auto-reload |
| `npm run seed` | server | Ricarica catalogo e coupon |
| `npm test` | server | Esegue gli 8 test automatici |
| `npm run dev` | client | Avvia il frontend |
| `npm run build` | client | Crea la build di produzione in `dist/` |

---

## Come si spegne tutto

Premi **Ctrl + C** in ciascuno dei due terminali. Oppure, per chiudere tutto in un colpo:

```powershell
Get-Process node | Stop-Process -Force
```

---

## Risoluzione problemi

| Problema | Causa | Soluzione |
|----------|-------|-----------|
| `node non riconosciuto` | PATH non aggiornato | Chiudi e riapri il terminale |
| `Port 4000 already in use` | Backend già avviato | `Get-Process node \| Stop-Process -Force` e riavvia |
| Il sito carica ma è senza prodotti | Backend spento o seed non eseguito | Verifica il terminale 1, lancia `npm run seed` |
| Ho lanciato il seed ma vedo i vecchi prodotti | Il server tiene il catalogo in memoria | **Riavvia il backend** dopo ogni seed |
| `Failed to load PostCSS config` | File `package.json` salvato con BOM UTF-8 | Risalvalo in UTF-8 **senza** BOM |
| Le email non arrivano nella casella | Modalità test Ethereal (default) | Normale: usa il link di anteprima mostrato a schermo e in console |

---

## Email: come funzionano

Di default `EMAIL_MODE=ethereal`: le mail **non arrivano in una casella reale**, ma ogni
invio genera un **link di anteprima** stampato nella console del backend e mostrato
nell'interfaccia dopo registrazione e pagamento.

Per ricevere email vere (es. su Gmail), crea `server/.env` e compila:

```
EMAIL_MODE=smtp
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_USER=tuoindirizzo@gmail.com
SMTP_PASS=app-password-di-16-caratteri
```

> Su Gmail serve una **App Password** (non la password normale dell'account),
> generabile dalle impostazioni di sicurezza Google con la verifica in 2 passaggi attiva.
